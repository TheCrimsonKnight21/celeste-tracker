import { parseAPLocation } from "./apParser";
import type { TrackerItem } from "../Data/types";


export function applyArchipelagoData(
  data: any,
  setMechanics: (m: any) => void
) {
  if (!data?.items) return;

setMechanics((prev: any) => ({
    ...prev,
    hasSprings: data.items.includes("Springs"),
    hasDashRefills: data.items.includes("Dash Refills") || data.items.includes("Dash Refill"),
    hasTrafficBlocks: data.items.includes("Traffic Blocks"),
    hasPinkCassetteBlocks: data.items.includes("Pink Cassette Blocks"),
    hasBlueCassetteBlocks: data.items.includes("Blue Cassette Blocks"),
    hasDreamBlocks: data.items.includes("Dream Blocks"),
    hasCoins: data.items.includes("Coins"),
    hasStrawberrySeeds: data.items.includes("Strawberry Seeds"),
    hasSinkingPlatforms: data.items.includes("Sinking Platforms"),
    hasMovingPlatforms: data.items.includes("Moving Platforms"),
    hasBlueClouds: data.items.includes("Blue Clouds"),
    hasPinkClouds: data.items.includes("Pink Clouds"),
    hasBlueBoosters: data.items.includes("Blue Boosters"),
    hasRedBoosters: data.items.includes("Red Boosters"),
    hasMoveBlocks: data.items.includes("Move Blocks"),
    hasWhiteBlock: data.items.includes("White Block"),
    hasSwapBlocks: data.items.includes("Swap Blocks"),
    hasDashSwitches: data.items.includes("Dash Switches"),
    hasTorches: data.items.includes("Torches"),
    hasTheoCrystal: data.items.includes("Theo Crystal"),
    hasFeathers: data.items.includes("Feathers"),
    hasBumpers: data.items.includes("Bumpers"),
    hasKevins: data.items.includes("Kevins"),
    hasBadelineBoosters: data.items.includes("Badeline Boosters"),
    hasFireAndIceBalls: data.items.includes("Fire and Ice Balls"),
    hasCoreToggles: data.items.includes("Core Toggles"),
    hasCoreBlocks: data.items.includes("Core Blocks"),
    hasPufferfish: data.items.includes("Pufferfish"),
    hasJellyfish: data.items.includes("Jellyfish"),
    hasDoubleDashRefills: data.items.includes("Double Dash Refills"),
    hasBreakerBoxes: data.items.includes("Breaker Boxes"),
    hasYellowCassetteBlocks: data.items.includes("Yellow Cassette Blocks"),
    hasGreenCassetteBlocks: data.items.includes("Green Cassette Blocks"),
    hasBird: data.items.includes("Bird")
}));
}

export function connectArchipelago(
  onItemUpdate: (item: TrackerItem) => void,
  onStatus: (connected: boolean) => void,
  setTrackerItems: React.Dispatch<React.SetStateAction<TrackerItem[]>>
) {
  const ws = new WebSocket("ws://localhost:38281");

  ws.onopen = () => {
    onStatus(true);
    ws.send(JSON.stringify({ cmd: "Connect" }));
  };

  ws.onclose = () => onStatus(false);

  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.cmd === "LocationChecks") {
      data.locations.forEach((locName: string) => {
        const parsed = parseAPLocation(locName);
        if (!parsed) return;

        registerAPLocation(parsed, setTrackerItems);

        onItemUpdate({
          ...parsed,
          collected: true
        });
      });
    }
  }
  return ws;
}

export function registerAPLocation(
  parsed: TrackerItem,
  setTrackerItems: React.Dispatch<React.SetStateAction<TrackerItem[]>>
) {
  setTrackerItems(prev => {
    if (prev.some(i => i.id === parsed.id)) return prev;
    return [...prev, { ...parsed, collected: false }];
  });
}
