import { useEffect, useState, useRef, useMemo } from "react";
import { type MechanicsState } from "../Logic/mechanics";
import { DebugOverlay } from "./DebugOverlay";
import { LOCATIONS, type LocationState, type LocationDef } from "../Data/locations";
import { createEmptyRandomizedMechanics, type RandomizedMechanicsState } from "../Logic/mechanics";
import LogicEditor from "./LogicEditor";
import { evaluateLogic } from "../Logic/logic";
import { MECHANIC_MAPPINGS } from "../Logic/mechanicsMapping";
import { LocationDebugger } from "./LocationDebugger";
import { LocationDiagnostic } from "./LocationDiagnostic";
import {useWebSocket }from "../Archipelago/useWebSocket";

/* ===============================
   Types
================================ */

type APMessage = any;
// let apSocket: WebSocket | null = null;
let pendingReceivedItems: number[] = [];

/* ===============================
   Helpers
================================ */

function simpleStringHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash) % 1000000; // Limit to reasonable range
}

function getMechanicKeyFromAPName(apName: string): keyof MechanicsState | null {
  console.log(`Looking for mapping for AP item: "${apName}"`);
  
  // First, try exact match in MECHANIC_MAPPINGS
  if (MECHANIC_MAPPINGS[apName]) {
    console.log(`Exact match found: "${apName}" -> "${MECHANIC_MAPPINGS[apName].logicKey}"`);
    return MECHANIC_MAPPINGS[apName].logicKey as keyof MechanicsState;
  }
  
  // Try to find a partial match
  for (const [apKey, mapping] of Object.entries(MECHANIC_MAPPINGS)) {
    if (apName.includes(apKey)) {
      console.log(`Partial match found: "${apName}" contains "${apKey}" -> "${mapping.logicKey}"`);
      return mapping.logicKey as keyof MechanicsState;
    }
  }
  
  // Handle special cases
  if (apName.includes("Dash Refill")) {
    return "dashrefills" as keyof MechanicsState;
  }
  
  // Check if it's a crystal heart (they all map to the same logic key)
  if (apName.includes("Crystal Heart")) {
    return "crystalheart" as keyof MechanicsState;
  }
  
  console.log(`No mapping found for "${apName}"`);
  return null;
}

const AREA_NAMES = [
  "Prologue",
  "Forsaken City",
  "Old Site",
  "Celestial Resort",
  "Golden Ridge",
  "Mirror Temple",
  "Reflection",
  "Summit",
  "Epilogue",
  "Farewell"
];

function getAreaName(chapter: number): string {
  return AREA_NAMES[chapter] ?? `Chapter ${chapter}`;
}

function getClientUUID(): string {
  const key = "ap-client-uuid";
  let uuid = localStorage.getItem(key);
  if (!uuid) {
    uuid = crypto.randomUUID();
    localStorage.setItem(key, uuid);
  }
  return uuid;
}

// Helper to extract required keys from logic node
function getRequiredKeysFromLogic(logic: any): string[] {
  const keys: string[] = [];
  
  if (logic.type === "has") {
    keys.push(logic.key);
  } else if (logic.type === "and" || logic.type === "or") {
    if (logic.nodes) {
      logic.nodes.forEach((node: any) => {
        keys.push(...getRequiredKeysFromLogic(node));
      });
    }
  }
  
  return keys;
}

// Helper to extract side from location ID (e.g., "Forsaken City A - Room 1" → "A")
function extractSideFromId(id: string): string | undefined {
  const match = id.match(/(\s+)([ABC])(\s+-\s+)/);
  if (match && match[2]) {
    return match[2];
  }
  
  // Check for patterns like "Old Site A" or "Celestial Resort B"
  const chapterMatch = id.match(/([ABC])\s+-\s+/);
  if (chapterMatch && chapterMatch[1]) {
    return chapterMatch[1];
  }
  
  return undefined;
}

// Helper to extract type from location display name
function extractTypeFromDisplayName(displayName: string): string | undefined {
  const lowerName = displayName.toLowerCase();
  
  if (lowerName.includes("strawberry") && !lowerName.includes("golden")) return "Strawberry";
  if (lowerName.includes("golden strawberry") || lowerName.includes("winged golden")) return "Golden Strawberry";
  if (lowerName.includes("cassette")) return "Cassette";
  if (lowerName.includes("heart")) return "Crystal Heart";
  if (lowerName.includes("key")) return "Key";
  if (lowerName.includes("moon berry")) return "Moon Berry";
  if (lowerName.includes("raspberry")) return "Raspberry";
  if (lowerName.includes("gem")) return "Gem";
  if (lowerName.includes("core") && lowerName.includes("crystal")) return "Crystal Heart";
  
  return undefined;
}

// Helper to check if location is a collectible type we want to display
function isCollectibleLocationDef(loc: LocationDef): boolean {
  const type = extractTypeFromDisplayName(loc.displayName);
  return type !== undefined;
}

function isCollectibleLocationState(loc: LocationState): boolean {
  const type = extractTypeFromDisplayName(loc.displayName);
  return type !== undefined;
}

// Helper to get mechanic display name
function getMechanicDisplayName(logicKey: string): string {
  for (const mapping of Object.values(MECHANIC_MAPPINGS)) {
    if (mapping.logicKey === logicKey) {
      return mapping.display;
    }
  }
  
  // Fallback formatting
  const formatted = logicKey.replace(/([A-Z])/g, ' $1').trim();
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

// Helper to enhance AP name matching
function enhanceAPNameMatching(apName: string): string {
  let enhanced = apName;
  
  // Handle Golden Ridge naming differences
  if (apName.includes("Golden Ridge A - Room a-")) {
    enhanced = apName.replace("Golden Ridge A - Room a-", "Golden Ridge A - ");
  }
  if (apName.includes("Golden Ridge A - Room b-")) {
    enhanced = apName.replace("Golden Ridge A - Room b-", "Golden Ridge A - ");
  }
  if (apName.includes("Golden Ridge A - Room c-")) {
    enhanced = apName.replace("Golden Ridge A - Room c-", "Golden Ridge A - ");
  }
  if (apName.includes("Golden Ridge A - Room d-")) {
    enhanced = apName.replace("Golden Ridge A - Room d-", "Golden Ridge A - ");
  }
  
  // Handle Gem locations
  if (apName.includes("The Summit A - Gem")) {
    const gemNum = apName.match(/Gem (\d+)/)?.[1];
    if (gemNum) {
      enhanced = `The Summit A - Gem ${gemNum}`;
    }
  }
  
  // Handle room naming patterns
  enhanced = enhanced.replace(/Room\s+/g, "Room ");
  enhanced = enhanced.replace(/\s+-\s+/g, " - ");
  
  return enhanced;
}

/* ===============================
   App
================================ */

export default function App() {

  const processedMessagesRef = useRef<Set<string>>(new Set());
  /* ---------- Logs ---------- */
  const [debugInfo, _] = useState<string>("");
  const [logs, setLogs] = useState<string[]>([]);
  const addLog = (line: string) =>
    setLogs((prev) => [`${new Date().toLocaleTimeString()}  ${line}`, ...prev].slice(0, 300));

  const logMechanicsChange = (oldMech: MechanicsState, newMech: MechanicsState) => {
    const changedKeys = Object.keys(oldMech).filter(key => 
      oldMech[key as keyof MechanicsState] !== newMech[key as keyof MechanicsState]
    );
    
    if (changedKeys.length > 0) {
      console.log("Mechanics changed:", changedKeys.map(k => 
        `${k}: ${oldMech[k as keyof MechanicsState]} -> ${newMech[k as keyof MechanicsState]}`
      ));
      addLog(`Mechanics updated: ${changedKeys.map(k => 
        `${getMechanicDisplayName(k)} (${k}): ${oldMech[k as keyof MechanicsState] ? "ON" : "OFF"} → ${newMech[k as keyof MechanicsState] ? "ON" : "OFF"}`
      ).join(", ")}`);
    }
  };

  /* ---------- Mechanics ---------- */
  const [mechanics, setMechanics] = useState<MechanicsState>(() => {
    const saved = localStorage.getItem("celeste-mechanics");
    return saved ? JSON.parse(saved) : createEmptyRandomizedMechanics();
  });

  useEffect(() => {
    console.log("Saving mechanics to localStorage:", mechanics);
    localStorage.setItem("celeste-mechanics", JSON.stringify(mechanics));
  }, [mechanics]);

  // Debug logging for mechanics changes
  useEffect(() => {
    console.log("Mechanics updated:", mechanics);
    console.log("Enabled mechanics:", Object.entries(mechanics).filter(([_, value]) => value).map(([key]) => key));
  }, [mechanics]);

  /* ---------- Randomized Mechanics ---------- */
  const randomizedMechanics: RandomizedMechanicsState = {
    ...createEmptyRandomizedMechanics(),
    ...mechanics,
  };

  /* ---------- Skills ---------- */
  const [allowSeq, setAllowSeq] = useState(true);

  /* ---------- Filters ---------- */
  const [selectedChapter, setSelectedChapter] = useState<string>("all");
  const [selectedSide, setSelectedSide] = useState<string>("all");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedReachability, setSelectedReachability] = useState<string>("all");

  // Extract unique values for filters from collectible locations only
  const collectibleLocationDefs = LOCATIONS.filter(isCollectibleLocationDef);
  const chapters = [...new Set(collectibleLocationDefs.map(l => l.chapter))].sort((a, b) => a - b);
  
  // Extract sides from collectible locations
  const sidesSet = new Set<string>();
  collectibleLocationDefs.forEach(loc => {
    const side = extractSideFromId(loc.id);
    if (side) sidesSet.add(side);
  });
  const sides = Array.from(sidesSet).sort();
  
  // Types from collectible locations
  const typesSet = new Set<string>();
  collectibleLocationDefs.forEach(loc => {
    const type = extractTypeFromDisplayName(loc.displayName);
    if (type) typesSet.add(type);
  });
  typesSet.add("Key");
  const types = Array.from(typesSet).sort();

  /* ===============================
     Unified Location State
  ================================ */
  const [locations, setLocations] = useState<Record<string, LocationState>>({});
  const [isInitialized, setIsInitialized] = useState(false);

  /* ---------- Initialize locations ---------- */
    /* ---------- Initialize locations ---------- */
  useEffect(() => {
    if (isInitialized) return;
    
    console.log("Initializing locations...");
    const savedLogic = JSON.parse(localStorage.getItem("celeste-location-logic") || "{}");
    const savedChecked = JSON.parse(localStorage.getItem("celeste-location-checked") || "{}");
    
    const initial: Record<string, LocationState> = {};
    LOCATIONS.forEach((loc) => {
      // Check if we have saved logic for this location
      // If not, use a default logic
      let defaultLogic = {
        type: "has" as const,
        key: "dashrefills"
      };
      
      // Try to get logic from saved, otherwise use default
      const logic = savedLogic[loc.id] || defaultLogic;
      
      initial[loc.id] = {
        ...loc,
        checked: savedChecked[loc.id] || false,
        reachable: false,
        logic: logic,
        apLocationId: undefined,
        apItemId: loc.apItemId || simpleStringHash(loc.id),
      };
    });
    
    console.log("Initial locations set:", Object.keys(initial).length);
    console.log("Checked locations loaded:", Object.values(initial).filter(l => l.checked).length);
    
    // Debug: Show which locations have logic
    const locationsWithCustomLogic = Object.values(initial).filter(l => savedLogic[l.id]);
    console.log("Locations with saved logic:", locationsWithCustomLogic.length);
    
    setLocations(initial);
    setIsInitialized(true);
  }, [isInitialized]);
  /* ---------- Calculate reachability ---------- */
const locationsWithReachability = useMemo(() => {
  if (!isInitialized || Object.keys(locations).length === 0) return locations;
  
  const next = { ...locations };
  Object.values(next).forEach((loc) => {
    try {
      const result = evaluateLogic(loc.logic, randomizedMechanics);
      
      if (!allowSeq && result.status === "sequence") {
        loc.reachable = false;
      } else {
        loc.reachable = result.status !== "locked";
      }
    } catch (error) {
      console.error(`Error evaluating logic for ${loc.id}:`, error);
      loc.reachable = false;
    }
  });
  
  return next;
}, [mechanics, allowSeq, isInitialized, locations]); 

  /* ---------- Save location logic ---------- */
useEffect(() => {
  if (!isInitialized) return;
  
  // Use a reference or check if there are actual changes
  const logicOut: Record<string, any> = {};
  const locationsSnapshot = locations; // Take snapshot
  
  Object.values(locationsSnapshot).forEach((loc) => {
    logicOut[loc.id] = loc.logic;
  });
  
  const jsonString = JSON.stringify(logicOut, null, 2);
  console.log("Saving location logic to localStorage, size:", jsonString.length);
  localStorage.setItem("celeste-location-logic", jsonString);
}, [isInitialized]); 

  /* ---------- Save checked locations ---------- */
  useEffect(() => {
    if (!isInitialized || Object.keys(locations).length === 0) return;
    
    const checkedOut: Record<string, boolean> = {};
    Object.values(locations).forEach((loc) => {
      checkedOut[loc.id] = loc.checked;
    });
    
    localStorage.setItem("celeste-location-checked", JSON.stringify(checkedOut));
    console.log("Saved checked locations:", Object.values(locations).filter(l => l.checked).length);
  }, [locations, isInitialized]);


  
  /* ===============================
     AP Dynamic Mappings
  ================================ */
  const itemIdToMechanicRef = useRef<Record<number, keyof MechanicsState>>({});
  const locationNameToIdRef = useRef<Record<string, number>>({});


/* ===============================
   Archipelago - WebSocket
================================ */

// Use the custom WebSocket hook
const { isConnected, send, socket } = useWebSocket({
  url: "ws://localhost:38281",
  onMessage: (data) => {
    if (Array.isArray(data)) {
      data.forEach(handleAPMessage);
    } else {
      handleAPMessage(data);
    }
  },
  onOpen: () => {
    console.log("✅ WebSocket opened successfully");
    addLog("✅ WebSocket connected to Archipelago");
    
    // Send connect message immediately - but only if socket is actually open
    setTimeout(() => {
      if (socket?.readyState === WebSocket.OPEN) {
        send([
          {
            cmd: "Connect",
            game: "Celeste (Open World)",
            name: "BBB",
            password: "",
            tags: ["Tracker"],
            items_handling: 7,
            uuid: getClientUUID(),
            version: { major: 0, minor: 5, build: 0, class: "Version" },
          },
        ]);
        console.log("Connect message sent to Archipelago");
      } else {
        console.log("Socket not open when trying to send Connect message");
      }
    }, 100); // Small delay to ensure socket is ready
  },
  onClose: (event) => {
    console.log("WebSocket closed:", event.code, event.reason);
    addLog(`🔌 WebSocket closed (${event.code} - ${event.reason || 'no reason'})`);
  },
  onError: (event) => {
    console.error("WebSocket error:", event);
    addLog("❌ WebSocket error occurred");
  },
  reconnectInterval: 10000, // Increased to 10 seconds
  maxReconnectAttempts: 5   // Reduced attempts
});

// Add this useEffect to debug connection state changes
useEffect(() => {
  console.log("Connection state changed:", {
    isConnected,
    socketReadyState: sendAPMessage,
    socketExists: !!socket
  });
}, [isConnected, socket]);

// Update all socket references to use the new send function
const sendAPMessage = (message: any) => {
  if (!send(message)) {
    console.log("Cannot send message, WebSocket not connected");
    addLog("⚠️ Cannot send message - WebSocket not connected");
    return false;
  }
  return true;
};

  function handleAPMessage(msg: APMessage) {
  // Create a unique ID for this message to prevent duplicate processing
  const msgId = `${msg.cmd}_${JSON.stringify(msg.data || msg.items || msg.locations || '')}`;
  
  // Check if we've already processed this message
  if (processedMessagesRef.current.has(msgId)) {
    console.log(`Skipping duplicate message: ${msg.cmd}`);
    return;
  }
  
  processedMessagesRef.current.add(msgId);
  
  // Limit the size of the processed messages set
  if (processedMessagesRef.current.size > 100) {
    const firstKey = processedMessagesRef.current.values().next().value;
    if (firstKey) {
      processedMessagesRef.current.delete(firstKey);
    }
  }
  
  addLog(`AP → ${msg.cmd}`);

    if (msg.cmd === "LocationChecks" || msg.cmd === "LocationInfo" || msg.cmd === "RoomUpdate") {
      // These might contain checked locations too
      console.log(`${msg.cmd} message:`, msg);
      
      // Try to extract checked locations
      let checkedLocations: number[] = [];
      
      if (msg.locations && Array.isArray(msg.locations)) {
        checkedLocations = msg.locations;
      } else if (msg.checked_locations && Array.isArray(msg.checked_locations)) {
        checkedLocations = msg.checked_locations;
      }
      
      if (checkedLocations.length > 0) {
        console.log(`${msg.cmd} has ${checkedLocations.length} checked locations`);
        
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
                console.log(`[${msg.cmd}] Marked as checked: ${loc.displayName}`);
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ ${msg.cmd} updated ${updatedCount} location(s)`);
          }
          return next;
        });
      }
    }

    if (msg.cmd === "ItemInfo") {
      // Handle initial items that were already received
      console.log("ItemInfo:", msg);
      
      if (msg.items && Array.isArray(msg.items)) {
        setMechanics((prev) => {
          const updated = { ...prev };
          let updatedCount = 0;
          
          for (const item of msg.items) {
            if (item.player === 1) { // Only our player's items
              const mech = itemIdToMechanicRef.current[item.item];
              if (mech && !updated[mech]) {
                updated[mech] = true;
                updatedCount++;
                addLog(`🔍 Loaded previously received item ${item.item} → ${mech}`);
              }
            }
          }
          
          if (updatedCount > 0) {
            addLog(`✅ Loaded ${updatedCount} previously received mechanics`);
          }
          return updated;
        });
      }
    }
    
    if (msg.cmd === "Connected") {
      addLog("✅ Successfully connected to Archipelago server");
      
      // Request DataPackage first
      setTimeout(() => {
        sendAPMessage([{ cmd: "GetDataPackage" }]);
        
        // Then request initial data after a short delay
        setTimeout(() => {
          sendAPMessage([{ 
            cmd: "Get",
            keys: ["checked_locations", "received_items"]
          }]);
          addLog("🔄 Auto-syncing checked locations and items");
        }, 1000);
      }, 500);
    }
        
    if (msg.cmd === "Retrieved") {
  console.log("=== RETRIEVED MESSAGE DEBUG ===");
  console.log("Full Retrieved message:", msg);
  
  if (msg.keys) {
    // Check for checked_locations
    if (msg.keys.checked_locations && Array.isArray(msg.keys.checked_locations)) {
      const checkedLocations = msg.keys.checked_locations;
      console.log(`Found checked_locations with ${checkedLocations.length} items`);
      
      if (checkedLocations.length > 0) {
        setLocations(prev => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
                console.log(`Marked as checked: ${loc.displayName} (AP ID: ${loc.apLocationId})`);
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ Loaded ${updatedCount} checked location(s) from Retrieved`);
          }
          return next;
        });
      }
    }
    
    // Check for received_items
    if (msg.keys.received_items && Array.isArray(msg.keys.received_items)) {
      console.log("Processing received_items from Retrieved");
      const receivedItems = msg.keys.received_items;
      
      setMechanics(prev => {
        const updated = { ...prev };
        let changed = false;
        
        receivedItems.forEach((item: any) => {
          if (typeof item === 'number') {
            const mech = itemIdToMechanicRef.current[item];
            if (mech && !updated[mech]) {
              updated[mech] = true;
              changed = true;
              console.log(`Setting ${mech} from received_items: ${item}`);
            }
          } else if (typeof item === 'object' && item.item) {
            const mech = itemIdToMechanicRef.current[item.item];
            if (mech && !updated[mech]) {
              updated[mech] = true;
              changed = true;
              console.log(`Setting ${mech} from received_items object: ${item.item}`);
            }
          }
        });
        
        return changed ? updated : prev;
      });
    }
  }
  
  console.log("=== END RETRIEVED DEBUG ===");
}

// Replace the entire DataPackage handler with this improved version:

if (msg.cmd === "DataPackage") {
  const game = msg.data.games["Celeste (Open World)"];
  if (!game) {
    addLog("❌ No Celeste game found in DataPackage");
    return;
  }

  console.log("=== DATAPACKAGE DEBUG ===");
  
  // Store location name to ID mapping
  locationNameToIdRef.current = game.location_name_to_id || {};
  
  // Helper function to categorize AP items
  const categorizeAPItem = (itemName: string): 'mechanic' | 'collectible' | 'other' => {
    const lowerName = itemName.toLowerCase();
    
    // These are mechanics (items that unlock abilities)
    const mechanicKeywords = [
      "spring", "traffic block", "cassette block", "dream block", "coin", 
      "strawberry seed", "sinking platform", "moving platform", "blue booster",
      "blue cloud", "move block", "white block", "swap block", "red booster",
      "torch", "theo crystal", "feather", "bumper", "kevin", "pink cloud",
      "badeline booster", "fire and ice", "core toggle", "core block",
      "pufferfish", "jellyfish", "breaker box", "dash refill", "double dash",
      "yellow cassette", "green cassette", "bird", "dash switch", "seeker"
    ];
    
    // These are collectible items (NOT mechanics) that appear as received items
    const collectibleItemKeywords = [
      "strawberry", "raspberry", "cassette", "key", "gem", "moon berry",
      "golden strawberry", "crystal heart" 
    ];
    
    // Special case: if it contains "cassette" but also "block", it's a mechanic
    if (lowerName.includes("cassette") && !lowerName.includes("block")) {
      return 'collectible'; // Cassettes without "block" are collectible items
    }
    
    if (mechanicKeywords.some(keyword => lowerName.includes(keyword))) {
      return 'mechanic';
    }
    
    if (collectibleItemKeywords.some(keyword => lowerName.includes(keyword))) {
      return 'collectible';
    }
    
    return 'other';
  };
  
  // Map AP item IDs to mechanics
  if (game.item_name_to_id) {
    const itemIdToMechanic: Record<number, keyof MechanicsState> = {};
    
    Object.entries(game.item_name_to_id).forEach(([apItemName, apItemId]) => {
      const category = categorizeAPItem(apItemName);
      
      if (category === 'mechanic') {
        const mechanicKey = getMechanicKeyFromAPName(apItemName);
        if (mechanicKey) {
          itemIdToMechanic[apItemId as number] = mechanicKey;
          addLog(`🔧 Mapped AP mechanic: ${apItemName} → ${mechanicKey}`);
        } else {
          console.log(`Could not find mechanic mapping for: ${apItemName}`);
        }
      } else if (category === 'collectible') {
        console.log(`📌 AP collectible item (not a mechanic): ${apItemName} (ID: ${apItemId})`);
        // These are items like Strawberries, Cassettes that are received as items
        // but don't unlock mechanics - they just increment item count
      } else {
        console.log(`❓ Other AP item: ${apItemName} (ID: ${apItemId})`);
      }
    });
    
    itemIdToMechanicRef.current = itemIdToMechanic;
    
    // Process any pending items now that we have mappings
    if (pendingReceivedItems.length > 0) {
      console.log(`Processing ${pendingReceivedItems.length} pending items`);
      setMechanics(prev => {
        const updated = { ...prev };
        let processedCount = 0;
        
        pendingReceivedItems.forEach(itemId => {
          const mech = itemIdToMechanic[itemId];
          if (mech && !updated[mech]) {
            updated[mech] = true;
            processedCount++;
            addLog(`🎁 Processed queued item ${itemId} → ${mech}`);
          }
        });
        
        pendingReceivedItems = [];
        if (processedCount > 0) {
          addLog(`✅ Processed ${processedCount} queued items`);
        }
        return updated;
      });
    }
  }

  // Map locations to AP IDs - focus on COLLECTIBLE locations
  setLocations(prev => {
    const next = { ...prev };
    let mappedCount = 0;
    let skippedCount = 0;
    
    // Create a reverse mapping for debugging and to prevent duplicates
    const apIdToLocationKey: Record<number, string> = {};
    
    if (game.location_name_to_id) {
      // First pass: collect all AP location names that are collectibles
      const apCollectibleLocations = Object.entries(game.location_name_to_id).filter(([apLocationName, _]) => {
        const lowerName = apLocationName.toLowerCase();
        
        // These are collectible location names in AP
        const apCollectiblePatterns = [
          "strawberry", "crystal heart", "cassette", "moon berry", 
          "golden strawberry", "raspberry", "key", "gem"
        ];
        
        // Also check for patterns like "Forsaken City A - Crossing" (these are NOT collectibles)
        // Collectibles usually have specific names, not just room names
        const isGenericRoomName = 
          lowerName.includes("crossing") ||
          lowerName.includes("chasm") ||
          lowerName.includes("intervention") ||
          lowerName.includes("awake") ||
          lowerName.includes("huge mess") ||
          lowerName.includes("shrine") ||
          lowerName.includes("depths") ||
          lowerName.includes("hollows") ||
          /\d+\s*m/.test(lowerName); // Patterns like "500 M"
        
        const hasCollectiblePattern = apCollectiblePatterns.some(pattern => lowerName.includes(pattern));
        
        return hasCollectiblePattern && !isGenericRoomName;
      });
      
      console.log(`Found ${apCollectibleLocations.length} collectible AP locations out of ${Object.keys(game.location_name_to_id).length} total`);
      
      // Second pass: match AP locations to our locations
      apCollectibleLocations.forEach(([apLocationName, apLocationId]) => {
        // Skip if this AP ID is already mapped
        if (apIdToLocationKey[apLocationId as number]) {
          console.log(`⚠️ AP ID ${apLocationId} already mapped to ${apIdToLocationKey[apLocationId as number]}, skipping "${apLocationName}"`);
          return;
        }
        
        // Enhance AP name for better matching
        const enhancedApName = enhanceAPNameMatching(apLocationName);
        
        // Try to find matching location in our collectible locations
        let bestMatchKey: string | null = null;
        let bestMatchScore = 0;
        
        Object.keys(next).forEach((key) => {
          const loc = next[key];
          
          // Only match collectible locations
          if (!isCollectibleLocationState(loc)) {
            return;
          }
          
          // Skip if this location already has an AP ID
          if (loc.apLocationId) {
            return;
          }
          
          // Calculate match score
          let score = 0;
          
          // Strategy 1: Exact match on display name (highest priority)
          if (loc.displayName === enhancedApName || loc.displayName === apLocationName) {
            score = 100;
          }
          
          // Strategy 2: Match by cleaned display name (remove extra spaces, etc.)
          const cleanDisplayName = loc.displayName.toLowerCase()
            .replace(/\s+/g, ' ')
            .trim();
          const cleanApName = enhancedApName.toLowerCase()
            .replace(/\s+/g, ' ')
            .trim();
          const cleanOriginalApName = apLocationName.toLowerCase()
            .replace(/\s+/g, ' ')
            .trim();
          
          if (cleanDisplayName === cleanApName || cleanDisplayName === cleanOriginalApName) {
            score = Math.max(score, 90);
          }
          
          // Strategy 3: Check if AP name contains our display name or vice versa
          if (cleanApName.includes(cleanDisplayName) || cleanDisplayName.includes(cleanApName)) {
            score = Math.max(score, 80);
          }
          
          // Strategy 4: Match by specific patterns
          // Extract chapter from both names
          const getChapterFromName = (name: string): number | null => {
            if (name.includes("prologue")) return 0;
            if (name.includes("forsaken city")) return 1;
            if (name.includes("old site")) return 2;
            if (name.includes("celestial resort")) return 3;
            if (name.includes("golden ridge")) return 4;
            if (name.includes("mirror temple")) return 5;
            if (name.includes("reflection")) return 6;
            if (name.includes("summit") || name.includes("the summit")) return 7;
            if (name.includes("epilogue")) return 8;
            if (name.includes("core")) return 9;
            if (name.includes("farewell")) return 10;
            return null;
          };
          
          const displayChapter = getChapterFromName(cleanDisplayName);
          const apChapter = getChapterFromName(cleanApName);
          
          if (displayChapter !== null && apChapter !== null && displayChapter === apChapter) {
            score += 20; // Same chapter
          }
          
          // Extract type from both names
          const displayType = extractTypeFromDisplayName(loc.displayName);
          const apType = extractTypeFromDisplayName(enhancedApName);
          
          if (displayType && apType && displayType === apType) {
            score += 20; // Same type
          }
          
          // Extract side from both names
          const displaySide = extractSideFromId(loc.id);
          const apHasSide = /[ABC]\s+-\s+/i.test(enhancedApName);
          const apSide = enhancedApName.match(/([ABC])\s+-\s+/i)?.[1];
          
          if (displaySide && apSide && displaySide.toUpperCase() === apSide.toUpperCase()) {
            score += 10; // Same side
          } else if (!displaySide && !apHasSide) {
            score += 5; // Both don't have sides specified
          }
          
          // Strategy 5: Match by room number patterns
          const displayRoomMatch = loc.displayName.match(/room\s+([a-z0-9\-]+)/i);
          const apRoomMatch = enhancedApName.match(/room\s+([a-z0-9\-]+)/i);
          
          if (displayRoomMatch && apRoomMatch && displayRoomMatch[1] === apRoomMatch[1]) {
            score += 15; // Same room number/identifier
          }
          
          // Update best match if this is better
          if (score > bestMatchScore && score > 50) { // Require at least some match confidence
            bestMatchScore = score;
            bestMatchKey = key;
          }
        });
        
        if (bestMatchKey && bestMatchScore > 50) {
          const loc = next[bestMatchKey];
          
          // Double-check we're not creating a duplicate
          if (loc.apLocationId) {
            console.log(`⚠️ Location ${bestMatchKey} already has AP ID ${loc.apLocationId}, skipping new assignment for "${apLocationName}"`);
            return;
          }
          
          // Update the location
          next[bestMatchKey] = { 
            ...loc, 
            apLocationId: apLocationId as number,
            apName: apLocationName,
            apItemId: simpleStringHash(apLocationName)
          };
          
          // Record the mapping to prevent duplicates
          apIdToLocationKey[apLocationId as number] = bestMatchKey;
          
          mappedCount++;
          console.log(`✅ Mapped (score: ${bestMatchScore}): ${apLocationName} (AP ID: ${apLocationId}) → "${loc.displayName}"`);
        } else {
          console.log(`❌ No good match found for AP location: "${apLocationName}" (ID: ${apLocationId})`);
          // Try enhanced name for debugging
          console.log(`   Enhanced AP name: "${enhancedApName}"`);
          
          // Try to find what might match
          const possibleMatches = Object.values(next)
            .filter(loc => isCollectibleLocationState(loc) && !loc.apLocationId)
            .filter(loc => {
              const cleanDisplayName = loc.displayName.toLowerCase();
              const cleanApName = enhancedApName.toLowerCase();
              return cleanDisplayName.includes(cleanApName.substring(0, Math.min(20, cleanApName.length))) || 
                     cleanApName.includes(cleanDisplayName.substring(0, Math.min(20, cleanDisplayName.length)));
            })
            .slice(0, 3);
          
          if (possibleMatches.length > 0) {
            console.log(`   Possible matches:`, possibleMatches.map(l => l.displayName));
          } else {
            console.log(`   No similar local locations found`);
          }
        }
      });
    }
    
    addLog(`✅ Mapped ${mappedCount} collectible locations to AP IDs`);
    console.log(`Total locations mapped: ${mappedCount}`);
    
    // Debug: Show what got mapped
    const mappedLocations = Object.values(next).filter(loc => loc.apLocationId);
    console.log("Mapped locations (first 10):", mappedLocations.slice(0, 10).map(l => ({
      name: l.displayName,
      apId: l.apLocationId,
      apName: l.apName,
      id: l.id
    })));
    
    // Show locations that didn't get mapped (for debugging)
    const unmappedCollectibles = Object.values(next).filter(loc => 
      isCollectibleLocationState(loc) && !loc.apLocationId
    );
    console.log(`Unmapped collectible locations: ${unmappedCollectibles.length}`);
    
    if (unmappedCollectibles.length > 0) {
      console.log("Sample unmapped collectibles (first 5):", 
        unmappedCollectibles.slice(0, 5).map(l => l.displayName));
    }
    
    // Now request checked locations
    setTimeout(() => {
      if (socket?.readyState === WebSocket.OPEN) {
        sendAPMessage(([{ 
          cmd: "Get",
          keys: ["checked_locations"]
        }]));
        addLog("🔄 Requesting checked locations after DataPackage");
      }
    }, 500);
    
    return next;
  });

  addLog("✅ Loaded AP Data Package");
}
    if (msg.cmd === "ReceivedItems") {
  console.log("ReceivedItems message:", msg);
  addLog(`📦 Received ${msg.items.length} items from Archipelago`);
  
  // Process items immediately
  for (const it of msg.items) {
    const mech = itemIdToMechanicRef.current[it.item];
    if (!mech) {
      console.log(`Item ${it.item} not yet mapped, adding to pending`);
      if (!pendingReceivedItems.includes(it.item)) {
        pendingReceivedItems.push(it.item);
      }
      continue;
    }
    
    // Update mechanics state
    setMechanics(prev => {
      if (prev[mech] === true) {
        // Already have this mechanic
        return prev;
      }
      
      console.log(`Setting mechanic ${mech} to true from item ${it.item}`);
      const updated = { ...prev, [mech]: true };
      logMechanicsChange(prev, updated);
      return updated;
    });
  }
  
  // If we have pending items and the DataPackage hasn't arrived yet,
  // request it again
  if (pendingReceivedItems.length > 0) {
    setTimeout(() => {
      sendAPMessage(([{ cmd: "GetDataPackage" }]));
    }, 1000);
  }
}

    if (msg.cmd === "RoomUpdate") {
      console.log("RoomUpdate:", msg);
      
      // Handle checked locations from RoomUpdate
      if (msg.checked_locations) {
        const checkedLocations = Array.isArray(msg.checked_locations) ? msg.checked_locations : [];
        console.log("RoomUpdate - checked locations:", checkedLocations);
        
        if (checkedLocations.length > 0) {
          setLocations((prev) => {
            const next = { ...prev };
            let updatedCount = 0;
            
            Object.keys(next).forEach((key) => {
              const loc = next[key];
              if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
                if (!loc.checked) {
                  // Create a new object instead of mutating
                  next[key] = { ...loc, checked: true };
                  updatedCount++;
                  addLog(`✅ Location checked: ${loc.displayName}`);
                }
              }
            });
            
            return next; // This returns a new object reference
          });
        }
      }
    }

    if (msg.cmd === "PrintJSON") {
      // Handle PrintJSON messages (chat messages)
      // Sometimes location checks come as PrintJSON messages
      if (msg.data && typeof msg.data === "string") {
        const dataStr = msg.data.toLowerCase();
        if (dataStr.includes("checked") || dataStr.includes("location")) {
          console.log("PrintJSON location check message:", msg.data);
          // Try to extract location information from the message
        }
      }
    }

    if (msg.cmd === "Bounced") {
      // Bounced messages often contain location checks
      console.log("Bounced message:", msg);
      
      if (msg.tags && msg.tags.includes("Client") && msg.data) {
        try {
          // Parse the bounced data which might contain location information
          const bouncedData = JSON.parse(msg.data);
          if (bouncedData.locations && Array.isArray(bouncedData.locations)) {
            const checkedLocations = bouncedData.locations;
            console.log("Bounced - checked locations:", checkedLocations);
            
            setLocations((prev) => {
              const next = { ...prev };
              let updatedCount = 0;
              
              Object.keys(next).forEach((key) => {
                const loc = next[key];
                if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
                  if (!loc.checked) {
                    next[key] = { ...loc, checked: true };
                    updatedCount++;
                    addLog(`✅ Bounced check: ${loc.displayName}`);
                  }
                }
              });
              
              return next;
            });
          }
        } catch (error) {
          console.error("Error parsing Bounced data:", error);
        }
      }
    }

    if (msg.cmd === "LocationInfo") {
      // LocationInfo messages contain location data
      console.log("LocationInfo:", msg);
      
      if (msg.locations && Array.isArray(msg.locations)) {
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          // LocationInfo can have an array of location objects
          msg.locations.forEach((locInfo: any) => {
            if (locInfo.status && locInfo.player && locInfo.location) {
              // Check if this location belongs to our player
              if (locInfo.player === 1) { // Player 1 is usually the local player
                Object.keys(next).forEach((key) => {
                  const loc = next[key];
                  if (loc.apLocationId === locInfo.location) {
                    const wasChecked = loc.checked;
                    const isChecked = locInfo.status > 0; // Status > 0 means checked
                    
                    if (!wasChecked && isChecked) {
                      next[key] = { ...loc, checked: true };
                      updatedCount++;
                      addLog(`✅ LocationInfo check: ${loc.displayName}`);
                    }
                  }
                });
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ Updated ${updatedCount} location(s) from LocationInfo`);
          }
          return next;
        });
      }
    }

    if (msg.cmd === "LocationChecks") {
      // When location checks are sent or received
      console.log("LocationChecks:", msg);
      if (msg.locations && Array.isArray(msg.locations)) {
        const checkedLocations = msg.locations;
        
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
                addLog(`✅ LocationChecks: ${loc.displayName}`);
              }
            }
          });
          
          return next;
        });
      }
    }
    
    if (msg.cmd === "SetReply") {
      // Handle SetReply messages which update client data
      if (msg.key === "checked_locations" && msg.value) {
        const checkedLocations = Array.isArray(msg.value) ? msg.value : [];
        console.log("SetReply - checked locations:", checkedLocations);
        
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ SetReply updated ${updatedCount} location(s)`);
          }
          return next;
        });
      }
    }

    if (msg.cmd === "ConnectionRefused") {
      addLog(`❌ Connection refused: ${msg.errors?.join(", ")}`);
    }

    if (msg.cmd === "ConnectionError") {
      addLog(`❌ Connection error: ${msg.errors?.join(", ")}`);
    }
  }

  /* ---------- Filter locations ---------- */
  const filteredLocations = Object.values(locations).filter((loc) => {
    // First, only show collectible locations
    if (!isCollectibleLocationState(loc)) return false;
    
    if (selectedChapter !== "all" && loc.chapter !== parseInt(selectedChapter)) return false;
    
    // Check side if filter is active
    if (selectedSide !== "all") {
      const locationSide = extractSideFromId(loc.id);
      if (!locationSide || locationSide !== selectedSide) return false;
    }
    
    // Check type if filter is active
    if (selectedType !== "all") {
      const locationType = extractTypeFromDisplayName(loc.displayName);
      if (!locationType || locationType !== selectedType) return false;
    }
    
    // Check reachability filter
    if (selectedReachability !== "all") {
      switch (selectedReachability) {
        case "reachable":
          if (!loc.reachable) return false;
          break;
        case "unreachable":
          if (loc.reachable) return false;
          break;
        case "checked":
          if (!loc.checked) return false;
          break;
        case "unchecked":
          if (loc.checked) return false;
          break;
      }
    }
    
    return true;
  });

// Group filtered locations by chapter for display
const locationsByChapter: Record<number, LocationState[]> = {};
const usedKeys = new Set<string>(); // Track used keys

filteredLocations.forEach((loc) => {
  // Skip if we've already used this key
  if (usedKeys.has(loc.id)) {
    console.warn(`Duplicate location key detected: ${loc.id} (${loc.displayName})`);
    return;
  }
  
  usedKeys.add(loc.id);
  
  if (!locationsByChapter[loc.chapter]) {
    locationsByChapter[loc.chapter] = [];
  }
  locationsByChapter[loc.chapter].push(loc);
});

  /* ---------- Handle location checking ---------- */
 const handleLocationCheck = (loc: LocationState) => {
  const locationType = extractTypeFromDisplayName(loc.displayName);
  
  // Only send checks for actual collectibles (not keys/gems if those are location-specific)
  if (loc.apLocationId && loc.reachable && !loc.checked) {
    // For keys, we might want different logic
    if (locationType === "Key") {
      // Keys might need special handling
      console.log(`Key location ${loc.displayName} would be checked`);
    }
    
    // Send check to Archipelago
    sendAPMessage(([
      {
        cmd: "LocationChecks",
        locations: [loc.apLocationId],
      },
    ]));
    
    // Update local state immediately
    setLocations(prev => ({
      ...prev,
      [loc.id]: { ...prev[loc.id], checked: true }
    }));
    
    addLog(`📍 Sent check for ${loc.displayName}`);
  }
};

  /* ===============================
     UI
  ================================ */

  if (!isInitialized) {
    return (
      <div style={{ padding: 20, maxWidth: 1200 }}>
        <h1>Celeste OW Archipelago Tracker</h1>
        <p>Loading locations and logic...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: 20, maxWidth: 1200 }}>
      <h1>🎮 Celeste OW Archipelago Tracker</h1>
      
      {/* Connection Status */}
      <div style={{ 
        padding: "10px", 
        marginBottom: "20px",
        background: isConnected ? "#4CAF50" : "#f44336",
        color: "white",
        borderRadius: "4px",
        fontWeight: "bold"
      }}>
        {isConnected ? "✅ Connected to Archipelago" : "❌ Not connected to Archipelago"}
        {socket?.readyState === WebSocket.CONNECTING && "🔄 Connecting..."}
      </div>

      {/* Main Controls */}
      <div style={{ 
        display: "flex", 
        gap: "20px", 
        marginBottom: "20px",
        flexWrap: "wrap",
        alignItems: "center"
      }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <input
            type="checkbox"
            checked={allowSeq}
            onChange={(e) => setAllowSeq(e.target.checked)}
          />
          <span>Allow Sequence Breaks</span>
        </label>
        <button
          onClick={() => {
            console.log("=== LOCATION MAPPING ANALYSIS ===");
            
            // Find locations with duplicate AP IDs
            const apIdMap: Record<number, string[]> = {};
            Object.values(locations).forEach(loc => {
              if (loc.apLocationId) {
                if (!apIdMap[loc.apLocationId]) {
                  apIdMap[loc.apLocationId] = [];
                }
                apIdMap[loc.apLocationId].push(loc.displayName);
              }
            });
            
            // Show duplicates
            Object.entries(apIdMap).forEach(([apId, names]) => {
              if (names.length > 1) {
                console.log(`❌ AP ID ${apId} mapped to multiple locations:`, names);
              }
            });
            
            // Show locations without AP IDs
            const locationsWithoutApIds = Object.values(locations)
              .filter(loc => isCollectibleLocationState(loc) && !loc.apLocationId);
            
            console.log(`Locations without AP IDs: ${locationsWithoutApIds.length}`);
            if (locationsWithoutApIds.length > 0) {
              console.log("Sample (first 10):", locationsWithoutApIds.slice(0, 10).map(l => l.displayName));
            }
            
            // Show AP location names from DataPackage
            console.log("AP location names from DataPackage (first 20):", 
              Object.keys(locationNameToIdRef.current).slice(0, 20));
          }}
          style={{
            padding: "8px 16px",
            background: "#607D8B",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Analyze Location Mapping
        </button>
        <button
          onClick={() => {
            console.log("=== TEST SEND ===");
            // Test sending a simple message
            const testMsg = [{ cmd: "ping" }];
            console.log("Sending:", testMsg);
            const result = send(testMsg);
            console.log("Send result:", result);
          }}
          style={{
            padding: "8px 16px",
            background: "#FF5722",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test Simple Send
        </button>
        <button
          onClick={() => {
            console.log("=== WEB SOCKET DEBUG ===");
            console.log("isConnected:", isConnected);
            console.log("socket readyState:", socket?.readyState);
            console.log("Socket states: 0=CONNECTING, 1=OPEN, 2=CLOSING, 3=CLOSED");
            console.log("socket exists:", !!socket);
            
            // Test if we can send a simple ping
            if (socket?.readyState === WebSocket.OPEN) {
              console.log("Socket is OPEN - testing ping...");
              send([{ cmd: "ping" }]);
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#9C27B0",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test WebSocket
        </button>
        <button
          onClick={() => {
            // Force close and reconnect
            if (socket) {
              socket.close();
              addLog("🔄 Manually closed socket for reconnection test");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#FF5722",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Force Reconnect
        </button>
        <button
          onClick={() => {
            console.log("=== CONNECTION DEBUG ===");
            console.log("isConnected:", isConnected);
            console.log("socket readyState:", socket?.readyState);
            console.log("Socket states: 0=CONNECTING, 1=OPEN, 2=CLOSING, 3=CLOSED");
            console.log("Processed messages:", processedMessagesRef.current.size);
            addLog(`🔍 Connection debug: isConnected=${isConnected}, readyState=${socket?.readyState}`);
          }}
          style={{
            padding: "8px 16px",
            background: "#607D8B",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Debug Connection
        </button>
        <button
          onClick={() => {
            if (socket?.readyState === WebSocket.OPEN) {
              sendAPMessage(([{
                cmd: "Get",
                keys: ["checked_locations"]
              }]));
              addLog("📤 Manually sent Get request for checked_locations");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#FF9800",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Force Get Checked Locations
        </button>
        <button
          onClick={() => {
            console.log("=== LOCATION MAPPING TEST ===");
            
            // Test if we have location_name_to_id
            if (Object.keys(locationNameToIdRef.current).length === 0) {
              console.log("❌ locationNameToIdRef is empty!");
              return;
            }
            
            // Test mapping for specific known locations
            const testMappings = [
              { apName: "Forsaken City - Crossing", expectedId: "Forsaken City A - Crossing" },
              { apName: "Old Site - Awake", expectedId: "Old Site A - Awake" },
              { apName: "Forsaken City - Chasm", expectedId: "Forsaken City A - Chasm" }
            ];
            
            testMappings.forEach(test => {
              const apId = locationNameToIdRef.current[test.apName];
              console.log(`AP Location "${test.apName}":`, apId ? `ID = ${apId}` : "NOT FOUND");
              
              // Find if this matches any of our locations
              const matchedLoc = Object.values(locations).find(loc => 
                loc.apLocationId === apId
              );
              console.log(`  Matched to local:`, matchedLoc ? matchedLoc.displayName : "NO MATCH");
            });
            
            // Check reverse mapping - our locations to AP IDs
            console.log("\nOur locations with AP IDs:");
            const locationsWithApIds = Object.values(locations).filter(loc => loc.apLocationId);
            locationsWithApIds.slice(0, 5).forEach(loc => {
              console.log(`  "${loc.displayName}" -> AP ID: ${loc.apLocationId}`);
              
              // Find the AP name for this ID
              const apName = Object.entries(locationNameToIdRef.current).find(
                ([_, id]) => id === loc.apLocationId
              );
              console.log(`    AP Name: ${apName ? apName[0] : "NOT FOUND"}`);
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#8BC34A",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test Location Mapping
        </button>
        <button
          onClick={() => {
            console.log("=== LOCATION MAPPING DEBUG ===");
            const locationsWithApIds = Object.values(locations).filter(loc => loc.apLocationId);
            const locationsWithoutApIds = Object.values(locations).filter(loc => !loc.apLocationId);
            
            console.log(`Total locations: ${Object.keys(locations).length}`);
            console.log(`Locations with AP IDs: ${locationsWithApIds.length}`);
            console.log(`Locations without AP IDs: ${locationsWithoutApIds.length}`);
            
            // Show sample of locations without AP IDs
            console.log("Sample locations without AP IDs:", 
              locationsWithoutApIds.slice(0, 10).map(l => l.displayName));
            
            // Show sample of AP location names from DataPackage
            console.log("Sample AP location names from DataPackage:", 
              Object.keys(locationNameToIdRef.current).slice(0, 10));
            
            // Check if specific known locations have AP IDs
            const testLocations = [
              "Old Site A - Crystal Heart?",
              "Forsaken City A - Strawberry 1",
              "Celestial Resort A - Strawberry 1"
            ];
            
            testLocations.forEach(testName => {
              const loc = Object.values(locations).find(l => l.displayName.includes(testName));
              if (loc) {
                console.log(`${testName}: AP ID = ${loc.apLocationId || 'NOT MAPPED'}`);
              }
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#607D8B",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Debug Location Mapping
        </button>
        <button
          onClick={() => {
            // Debug specific room that's not getting checked
            const room5z = Object.values(locations).find(l => 
              l.displayName.includes("Room 5z") || 
              l.displayName.includes("Room 5a")
            );
            
            if (room5z) {
              console.log("Room 5z/5a debug:", {
                name: room5z.displayName,
                apId: room5z.apLocationId,
                checked: room5z.checked,
                apName: room5z.apName
              });
              
              // Check if this AP ID matches any AP location
              const apLocation = Object.entries(locationNameToIdRef.current).find(
                ([name, id]) => id === room5z.apLocationId
              );
              console.log("AP Location match:", apLocation);
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#FF9800",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Debug Room 5z/5a
        </button>
        <button
          onClick={() => {
            // Manually mark first 5 locations as checked for testing
            setLocations(prev => {
              const next = { ...prev };
              let count = 0;
              
              Object.keys(next).forEach(key => {
                if (count < 5 && !next[key].checked && next[key].apLocationId) {
                  next[key] = { ...next[key], checked: true };
                  count++;
                  console.log(`Marked ${next[key].displayName} as checked (AP ID: ${next[key].apLocationId})`);
                }
              });
              
              addLog(`✅ Manually checked ${count} locations for testing`);
              return next;
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#E91E63",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Check 5 Locations
        </button>
        <button
          onClick={() => {
            if (socket?.readyState === WebSocket.OPEN) {
              sendAPMessage(([{ 
                cmd: "Get",
                keys: ["checked_locations", "received_items", "missing_locations"]
              }]));
              addLog("🔄 Manually requested full state sync");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#795548",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Full State Sync
        </button>
        <button
          onClick={() => {
            setMechanics(prev => {
              const updated = { ...prev };
              // Toggle the first mechanic as a test
              const firstKey = Object.keys(updated)[0] as keyof MechanicsState;
              updated[firstKey] = !updated[firstKey];
              console.log(`Toggled ${firstKey}: ${!prev[firstKey]} -> ${updated[firstKey]}`);
              return updated;
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#FF4081",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Toggle First Mechanic
        </button>
        <button
          onClick={() => {
            if (socket?.readyState === WebSocket.OPEN) {
              // First get DataPackage to ensure we have mappings
              sendAPMessage(([{ cmd: "GetDataPackage" }]));
              // Then get checked locations
              setTimeout(() => {
                sendAPMessage(([{ 
                  cmd: "Get",
                  keys: ["checked_locations", "received_items"]
                }]));
              }, 1000);
              addLog("🔄 Manual sync: Requesting DataPackage and state");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Force Full Sync
        </button>
        <button
          onClick={() => {
            // Force a re-render of mechanics
            setMechanics(prev => ({ ...prev }));
            addLog("🔄 Manually refreshed mechanics display");
            
          }}
          style={{
            padding: "8px 16px",
            background: "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Refresh Mechanics Display
        </button>
        <button
          onClick={() => {
            // Manually request checked locations
            if (socket?.readyState === WebSocket.OPEN) {
              sendAPMessage(([{ 
                cmd: "Get",
                keys: ["checked_locations"]
              }]));
              addLog("🔄 Manually requested checked locations");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#9c27b0",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Sync Checked Locations
        </button>
        <button
          onClick={() => {
            if (socket?.readyState === WebSocket.OPEN) {
              // Clear localStorage and force fresh sync
              localStorage.removeItem("celeste-location-checked");
              localStorage.removeItem("celeste-mechanics");
              
              // Request fresh data
              sendAPMessage([{ cmd: "GetDataPackage" }]);
              setTimeout(() => {
                sendAPMessage([{ 
                  cmd: "Get",
                  keys: ["checked_locations", "received_items", "missing_locations"]
                }]);
              }, 1000);
              
              addLog("🔄 Force reset and sync initiated");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#f44336",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Force Reset & Sync
        </button>
        <button
          onClick={() => {
            // Test: Mark all reachable locations as checked
            setLocations(prev => {
              const next = { ...prev };
              Object.values(next).forEach(loc => {
                if (loc.reachable && !loc.checked) {
                  loc.checked = true;
                }
              });
              return next;
            });
            addLog("⚠️ Marked all reachable locations as checked (TEST)");
            
            // Force save
            const checkedOut: Record<string, boolean> = {};
            Object.values(locations).forEach((loc) => {
              checkedOut[loc.id] = loc.checked;
            });
            localStorage.setItem("celeste-location-checked", JSON.stringify(checkedOut));
          }}
          style={{
            padding: "8px 16px",
            background: "#ff9800",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Mark All Reachable
        </button>
        
        <button
          onClick={() => {
            setMechanics(prev => ({
              ...prev,
              "dashrefills": true
            }));
            console.log("Manually set dashrefills to true");
          }}
          style={{
            padding: "8px 16px",
            background: "#4CAF50",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Set Dash Refills
        </button>
        
        <button
          onClick={() => {
            setLocations(prev => {
              const next = { ...prev };
              Object.keys(next).forEach(key => {
                next[key] = { ...next[key], checked: false };
              });
              return next;
            });
            addLog("🗑️ Cleared all checked locations");
            
            // Force save
            const checkedOut: Record<string, boolean> = {};
            Object.values(locations).forEach((loc) => {
              checkedOut[loc.id] = false;
            });
            localStorage.setItem("celeste-location-checked", JSON.stringify(checkedOut));
          }}
          style={{
            padding: "8px 16px",
            background: "#ff5722",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Clear All Checked
        </button>
        
        <button
          onClick={() => {
            console.log("=== DEBUG STATE ===");
            console.log("Total locations:", Object.keys(locations).length);
            console.log("Collectible locations:", filteredLocations.length);
            console.log("Mechanics:", mechanics);
            
            // Show connection info
            console.log("WebSocket state:", socket?.readyState);
          }}
          style={{
            padding: "8px 16px",
            background: "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Debug State
        </button>
      </div>

      {/* Filters */}
      <div style={{ 
        display: "grid", 
        gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", 
        gap: "15px",
        marginBottom: "30px",
        padding: "15px",
        background: "#f5f5f5",
        borderRadius: "8px"
      }}>
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Chapter:
          </label>
          <select 
            value={selectedChapter}
            onChange={(e) => setSelectedChapter(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All Chapters</option>
            {chapters.map(ch => (
              <option key={ch} value={ch}>
                {getAreaName(ch)} ({ch})
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Side:
          </label>
          <select 
            value={selectedSide}
            onChange={(e) => setSelectedSide(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All Sides</option>
            {sides.map(side => (
              <option key={side} value={side}>Side {side}</option>
            ))}
          </select>
        </div>
        
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Type:
          </label>
          <select 
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All Types</option>
            {types.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        
        {/* Add Reachability Filter */}
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Reachability:
          </label>
          <select 
            value={selectedReachability}
            onChange={(e) => setSelectedReachability(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All</option>
            <option value="reachable">Reachable Only</option>
            <option value="unreachable">Unreachable Only</option>
            <option value="checked">Checked Only</option>
            <option value="unchecked">Unchecked Only</option>
          </select>
        </div>
        
        <div style={{ display: "flex", alignItems: "flex-end" }}>
          <button
            onClick={() => {
              setSelectedChapter("all");
              setSelectedSide("all");
              setSelectedType("all");
              setSelectedReachability("all");
            }}
            style={{
              padding: "8px 16px",
              background: "#9e9e9e",
              color: "white",
              border: "none",
              borderRadius: "4px",
              width: "100%"
            }}
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ 
        display: "grid", 
        gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", 
        gap: "10px",
        marginBottom: "20px"
      }}>
        <div style={{ 
          padding: "10px", 
          background: "#e3f2fd", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Collectibles</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#e8f5e9", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Reachable</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => l.reachable).length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#fff3e0", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Checked</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => l.checked).length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#fce4ec", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Locked</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => !l.reachable).length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#f3e5f5", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Unchecked</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => !l.checked).length}
          </div>
        </div>
      </div>

      {/* Current Mechanics - Display with proper names */}
      <div style={{ marginBottom: "30px" }}>
        <h2>Current Mechanics ({Object.values(mechanics).filter(v => v).length}/{Object.keys(mechanics).length})</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 8 }}>
          {Object.entries(mechanics).map(([key, value]) => {
            const displayName = getMechanicDisplayName(key);
            
            return (
              <div key={key} style={{ 
                padding: 8, 
                background: value ? "#4CAF50" : "#f5f5f5",
                color: value ? "white" : "#333",
                border: `1px solid ${value ? "#4CAF50" : "#ddd"}`,
                borderRadius: "4px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }}>
                <span>{displayName}</span>
                <span style={{ fontWeight: "bold" }}>{value ? "✓" : "✗"}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Locations Display - Only Collectibles */}
      {Object.keys(locationsByChapter).length > 0 ? (
        Object.keys(locationsByChapter).sort((a, b) => parseInt(a) - parseInt(b)).map((chapterKey) => {
          const chapterNum = parseInt(chapterKey);
          const chapterLocations = locationsByChapter[chapterNum];
          
          return (
            <div key={chapterNum} style={{ marginBottom: "30px" }}>
              <h2 style={{ 
                padding: "10px", 
                background: "#673ab7", 
                color: "white",
                borderRadius: "4px"
              }}>
                {getAreaName(chapterNum)} (Chapter {chapterNum}) - {chapterLocations.length} collectibles
              </h2>
              
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(400px, 1fr))", gap: "15px" }}>
                {chapterLocations.map((loc) => {
                  const requiredKeys = getRequiredKeysFromLogic(loc.logic);
                  const locationSide = extractSideFromId(loc.id);
                  const locationType = extractTypeFromDisplayName(loc.displayName);
                  
                  return (
                    <div key={loc.id} style={{ 
                      opacity: loc.reachable ? 1 : 0.6,
                      padding: "15px",
                      background: loc.reachable ? (loc.checked ? "#000000ff" : "#000000ff") : "#000000ff",
                      border: `2px solid ${loc.checked ? "#2196F3" : loc.reachable ? "#4CAF50" : "#9e9e9e"}`,
                      borderRadius: "8px",
                      transition: "all 0.2s"
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "10px" }}>
                        <input
                          type="checkbox"
                          checked={loc.checked}
                          disabled={!loc.reachable || loc.checked}
                          onChange={() => handleLocationCheck(loc)}
                          style={{ 
                            transform: "scale(1.3)",
                            cursor: loc.reachable && !loc.checked ? "pointer" : "not-allowed"
                          }}
                        />
                        <span style={{ 
                          fontSize: "1.3em",
                          fontWeight: "bold" 
                        }}>
                          {loc.checked ? "🔵" : loc.reachable ? "🟢" : "⚫"}
                        </span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: "bold", fontSize: "1.1em" }}>{loc.displayName}</div>
                          <div style={{ fontSize: "0.9em", color: "#666", display: "flex", gap: "10px", marginTop: "4px" }}>
                            {locationSide && <span>Side: {locationSide}</span>}
                            {locationType && <span>Type: {locationType}</span>}
                          </div>
                        </div>
                        {loc.apLocationId && (
                          <span style={{ 
                            fontSize: "0.8em", 
                            color: "#666",
                            background: "#f0f0f0",
                            padding: "2px 6px",
                            borderRadius: "3px"
                          }}>
                            AP: {loc.apLocationId}
                          </span>
                        )}
                      </div>
                      
                      <div style={{ margin: "10px 0" }}>
                        <LogicEditor
                          logic={loc.logic}
                          onChange={(logic) =>
                            setLocations((prev) => ({
                              ...prev,
                              [loc.id]: { ...loc, logic },
                            }))
                          }
                          mechanics={mechanics}
                        />
                      </div>
                      
                      {/* Location Info */}
                      <div style={{ 
                        fontSize: "0.85em", 
                        color: "#666",
                        padding: "8px",
                        background: "#f9f9f9",
                        borderRadius: "4px",
                        border: "1px solid #eee"
                      }}>
                        <div style={{ marginBottom: "4px" }}>
                          <strong>Status:</strong> {loc.checked ? "Checked" : loc.reachable ? "Reachable" : "Locked"}
                        </div>
                        {requiredKeys.length > 0 && (
                          <div style={{ marginBottom: "4px" }}>
                            <strong>Required:</strong> {requiredKeys.map(k => getMechanicDisplayName(k)).join(", ")}
                          </div>
                        )}
                        <div style={{ 
                          color: loc.reachable ? "#4CAF50" : "#f44336",
                          fontWeight: "bold"
                        }}>
                          {loc.reachable ? "✓ Accessible" : "✗ Locked"}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })
      ) : (
        <div style={{ 
          padding: "20px", 
          textAlign: "center", 
          background: "#f5f5f5",
          borderRadius: "8px",
          marginBottom: "20px"
        }}>
          <h3>No collectible locations match the current filters</h3>
          <p>Try adjusting your filter settings</p>
        </div>
      )}

      {/* Debug Panel */}
      <details style={{ marginBottom: "20px" }}>
        <summary style={{ cursor: "pointer", padding: "10px", background: "#333", color: "white", borderRadius: "4px" }}>
          Debug Panel
        </summary>
        <div>
          <h3>Debug Logic Output</h3>
          <textarea 
            value={debugInfo}
            readOnly
            style={{
              width: "100%",
              height: "200px",
              fontFamily: "monospace",
              fontSize: "10px",
              marginBottom: "10px"
            }}
          />
          <button
            onClick={() => {
              // Test: Check if we can find locations for received items
              console.log("=== ITEM MATCHING TEST ===");
              const testItemIds = [211886104, 211886080, 211886085];
              
              testItemIds.forEach(itemId => {
                const locationKey = Object.keys(locations).find(key => 
                  locations[key].apItemId === itemId
                );
                
                if (locationKey) {
                  console.log(`✅ Item ${itemId} matches location: "${locations[locationKey].displayName}"`);
                } else {
                  console.log(`❌ Item ${itemId} - NO MATCHING LOCATION FOUND`);
                  
                  // Show all locations with apItemId
                  const locationsWithApItemId = Object.values(locations).filter(l => l.apItemId);
                  console.log(`Locations with apItemId:`, locationsWithApItemId.map(l => ({
                    displayName: l.displayName,
                    apItemId: l.apItemId
                  })));
                }
              });
            }}
            style={{
              padding: "8px 16px",
              background: "#ff5722",
              color: "white",
              border: "none",
              borderRadius: "4px"
            }}
          >
            Test Item Matching
          </button>
          <button
            onClick={() => {
              // Clear all mechanics for testing
              setMechanics(createEmptyRandomizedMechanics());
            }}
            style={{
              padding: "8px 16px",
              background: "#ff9800",
              color: "white",
              border: "none",
              borderRadius: "4px",
              marginRight: "10px"
            }}
          >
            Reset All Mechanics
          </button>
          
          <button
            onClick={() => {
              // Set all mechanics for testing
              setMechanics(prev => {
                const allTrue: MechanicsState = {} as MechanicsState;
                Object.keys(prev).forEach(key => {
                  allTrue[key as keyof MechanicsState] = true;
                });
                return allTrue;
              });
            }}
            style={{
              padding: "8px 16px",
              background: "#4CAF50",
              color: "white",
              border: "none",
              borderRadius: "4px"
            }}
          >
            Unlock All Mechanics
          </button>
        </div>
      </details>

      {/* Logs */}
      <div>
        <h2>Logs ({logs.length})</h2>
        <div
          style={{
            background: "#111",
            color: "#0f0",
            padding: 12,
            height: 300,
            overflowY: "auto",
            fontFamily: "monospace",
            fontSize: 12,
            borderRadius: "4px"
          }}
        >
          {logs.length > 0 ? (
            logs.map((l, i) => (
              <div key={i} style={{ 
                padding: "2px 0",
                borderBottom: i < logs.length - 1 ? "1px solid #333" : "none"
              }}>
                {l}
              </div>
            ))
          ) : (
            <div style={{ color: "#888", textAlign: "center", padding: "20px" }}>
              No logs yet
            </div>
          )}
        </div>
        <button
          onClick={() => setLogs([])}
          style={{
            marginTop: "10px",
            padding: "8px 16px",
            background: "#666",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Clear Logs
        </button>
      </div>
      <LocationDiagnostic locations={locationsWithReachability} />
      <LocationDebugger locations={locationsWithReachability} />
      <DebugOverlay mechanics={mechanics} locations={locationsWithReachability} />
    </div>
  );
}