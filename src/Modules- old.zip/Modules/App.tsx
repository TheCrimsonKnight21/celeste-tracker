import { useEffect, useState, useRef } from "react";
import { type MechanicsState, RANDOMIZED_MECHANICS } from "../Logic/mechanics";
import { DebugOverlay } from "./DebugOverlay";
import { LOCATIONS, type LocationState, type LocationDef } from "../Data/locations";
import { createEmptyRandomizedMechanics, type RandomizedMechanicsState } from "../Logic/mechanics";
import LogicEditor from "./LogicEditor";
import { evaluateLogic } from "../Logic/logic";
import { MECHANIC_MAPPINGS } from "../Logic/mechanicsMapping";
import { LocationDebugger } from "./LocationDebugger";
import { LocationDiagnostic } from "./LocationDiagnostic";

/* ===============================
   Types
================================ */

type APMessage = any;
let apSocket: WebSocket | null = null;
let pendingReceivedItems: number[] = [];

/* ===============================
   Helpers
================================ */

function getMechanicKeyFromAPName(apName: string): keyof MechanicsState | null {
  console.log(`Looking for mapping for AP item: "${apName}"`);
  
  // Try to match the AP name to a logic key
  for (const [apKey, mapping] of Object.entries(MECHANIC_MAPPINGS)) {
    if (apName === apKey || apName.includes(apKey)) {
      console.log(`Matched "${apName}" to "${apKey}" -> "${mapping.logicKey}"`);
      return mapping.logicKey as keyof MechanicsState;
    }
  }
  
  // Fallback: try to convert AP name to logic key
  const logicKey = apName.toLowerCase().replace(/\s+/g, '');
  if (RANDOMIZED_MECHANICS.includes(logicKey as any)) {
    console.log(`Fallback matched "${apName}" to logic key "${logicKey}"`);
    return logicKey as keyof MechanicsState;
  }
  
  console.log(`No mapping found for "${apName}"`);
  return null;
}

const AREA_NAMES = [
  "Prologue",
  "Forsaken City",
  "Old Site",
  "Celestial Resort",
  "Golden Ridge",
  "Mirror Temple",
  "Reflection",
  "Summit",
  "Epilogue",
  "Farewell"
];

function getAreaName(chapter: number): string {
  return AREA_NAMES[chapter] ?? `Chapter ${chapter}`;
}

function getClientUUID(): string {
  const key = "ap-client-uuid";
  let uuid = localStorage.getItem(key);
  if (!uuid) {
    uuid = crypto.randomUUID();
    localStorage.setItem(key, uuid);
  }
  return uuid;
}

// Helper to extract required keys from logic node
function getRequiredKeysFromLogic(logic: any): string[] {
  const keys: string[] = [];
  
  if (logic.type === "has") {
    keys.push(logic.key);
  } else if (logic.type === "and" || logic.type === "or") {
    if (logic.nodes) {
      logic.nodes.forEach((node: any) => {
        keys.push(...getRequiredKeysFromLogic(node));
      });
    }
  }
  
  return keys;
}

// Helper to extract side from location ID (e.g., "Forsaken City A - Room 1" → "A")
function extractSideFromId(id: string): string | undefined {
  const match = id.match(/(\s+)([ABC])(\s+-\s+)/);
  if (match && match[2]) {
    return match[2];
  }
  
  // Check for patterns like "Old Site A" or "Celestial Resort B"
  const chapterMatch = id.match(/([ABC])\s+-\s+/);
  if (chapterMatch && chapterMatch[1]) {
    return chapterMatch[1];
  }
  
  return undefined;
}

// Helper to extract type from location display name
function extractTypeFromDisplayName(displayName: string): string | undefined {
  const lowerName = displayName.toLowerCase();
  
  if (lowerName.includes("strawberry")) return "Strawberry";
  if (lowerName.includes("crystal heart") || lowerName.includes("crystal heart?")) return "Crystal Heart";
  if (lowerName.includes("cassette")) return "Cassette";
  if (lowerName.includes("moon berry")) return "Moon Berry";
  if (lowerName.includes("golden strawberry")) return "Golden Strawberry";
  
  return undefined;
}

// Helper to check if location is a collectible type we want to display
function isCollectibleLocationDef(loc: LocationDef): boolean {
  const type = extractTypeFromDisplayName(loc.displayName);
  return type !== undefined;
}

function isCollectibleLocationState(loc: LocationState): boolean {
  const type = extractTypeFromDisplayName(loc.displayName);
  return type !== undefined;
}

// Helper to get mechanic display name
function getMechanicDisplayName(logicKey: string): string {
  for (const mapping of Object.values(MECHANIC_MAPPINGS)) {
    if (mapping.logicKey === logicKey) {
      return mapping.display;
    }
  }
  
  // Fallback formatting
  const formatted = logicKey.replace(/([A-Z])/g, ' $1').trim();
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

/* ===============================
   App
================================ */

export default function App() {
  /* ---------- Logs ---------- */
  const [debugInfo, setDebugInfo] = useState<string>("");
  const [logs, setLogs] = useState<string[]>([]);
  const addLog = (line: string) =>
    setLogs((prev) => [`${new Date().toLocaleTimeString()}  ${line}`, ...prev].slice(0, 300));

  const logMechanicsChange = (oldMech: MechanicsState, newMech: MechanicsState) => {
    const changedKeys = Object.keys(oldMech).filter(key => 
      oldMech[key as keyof MechanicsState] !== newMech[key as keyof MechanicsState]
    );
    
    if (changedKeys.length > 0) {
      console.log("Mechanics changed:", changedKeys.map(k => 
        `${k}: ${oldMech[k as keyof MechanicsState]} -> ${newMech[k as keyof MechanicsState]}`
      ));
      addLog(`Mechanics updated: ${changedKeys.map(k => 
        `${getMechanicDisplayName(k)} (${k}): ${oldMech[k as keyof MechanicsState] ? "ON" : "OFF"} → ${newMech[k as keyof MechanicsState] ? "ON" : "OFF"}`
      ).join(", ")}`);
    }
  };

  /* ---------- Mechanics ---------- */
  const [mechanics, setMechanics] = useState<MechanicsState>(() => {
    const saved = localStorage.getItem("celeste-mechanics");
    return saved ? JSON.parse(saved) : createEmptyRandomizedMechanics();
  });

  useEffect(() => {
    console.log("Saving mechanics to localStorage:", mechanics);
    localStorage.setItem("celeste-mechanics", JSON.stringify(mechanics));
  }, [mechanics]);

  // Debug logging for mechanics changes
  useEffect(() => {
    console.log("Mechanics updated:", mechanics);
    console.log("Enabled mechanics:", Object.entries(mechanics).filter(([_, value]) => value).map(([key]) => key));
  }, [mechanics]);

  /* ---------- Randomized Mechanics ---------- */
  const randomizedMechanics: RandomizedMechanicsState = {
    ...createEmptyRandomizedMechanics(),
    ...mechanics,
  };

  /* ---------- Skills ---------- */
  const [allowSeq, setAllowSeq] = useState(true);

  /* ---------- Filters ---------- */
  const [selectedChapter, setSelectedChapter] = useState<string>("all");
  const [selectedSide, setSelectedSide] = useState<string>("all");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedReachability, setSelectedReachability] = useState<string>("all");

  // Extract unique values for filters from collectible locations only
  const collectibleLocationDefs = LOCATIONS.filter(isCollectibleLocationDef);
  const chapters = [...new Set(collectibleLocationDefs.map(l => l.chapter))].sort((a, b) => a - b);
  
  // Extract sides from collectible locations
  const sidesSet = new Set<string>();
  collectibleLocationDefs.forEach(loc => {
    const side = extractSideFromId(loc.id);
    if (side) sidesSet.add(side);
  });
  const sides = Array.from(sidesSet).sort();
  
  // Types from collectible locations
  const typesSet = new Set<string>();
  collectibleLocationDefs.forEach(loc => {
    const type = extractTypeFromDisplayName(loc.displayName);
    if (type) typesSet.add(type);
  });
  const types = Array.from(typesSet).sort();

  /* ===============================
     Unified Location State
  ================================ */
  const [locations, setLocations] = useState<Record<string, LocationState>>({});
  const [isInitialized, setIsInitialized] = useState(false);

  /* ---------- Initialize locations ---------- */
  useEffect(() => {
    if (isInitialized) return;
    
    console.log("Initializing locations...");
    const savedLogic = JSON.parse(localStorage.getItem("celeste-location-logic") || "{}");
    const savedChecked = JSON.parse(localStorage.getItem("celeste-location-checked") || "{}");
    
    const initial: Record<string, LocationState> = {};
    LOCATIONS.forEach((loc) => {
      const defaultLogic = savedLogic[loc.id] || {
        type: "and",
        nodes: [
          { 
            type: "has", 
            key: "dashrefills"  // Changed to logic key
          }
        ]
      };
      
      initial[loc.id] = {
        ...loc,
        checked: savedChecked[loc.id] || false,
        reachable: false,
        logic: defaultLogic,
        apLocationId: undefined,
        apItemId: 0,
      };
    });
    
    console.log("Initial locations set:", Object.keys(initial).length);
    console.log("Checked locations loaded:", Object.values(initial).filter(l => l.checked).length);
    setLocations(initial);
    setIsInitialized(true);
  }, [isInitialized]);

  /* ---------- Recalculate reachability ---------- */
  useEffect(() => {
    if (!isInitialized || Object.keys(locations).length === 0) return;
    
    console.log("Recalculating reachability with mechanics:", mechanics);
    setLocations((prev) => {
      const next = { ...prev };
      let debugText = "Reachability calculation:\n";
      
      Object.values(next).forEach((loc) => {
        try {
          const result = evaluateLogic(loc.logic, randomizedMechanics);
          debugText += `${loc.id}: ${JSON.stringify(result)}\n`;
          
          if (!allowSeq && result.status === "sequence") {
            loc.reachable = false;
          } else {
            loc.reachable = result.status !== "locked";
          }
        } catch (error) {
          console.error(`Error evaluating logic for ${loc.id}:`, error);
          debugText += `${loc.id}: ERROR - ${error}\n`;
          loc.reachable = false;
        }
      });
      
      setDebugInfo(debugText);
      return next;
    });
  }, [mechanics, allowSeq, isInitialized, locations]);

  /* ---------- Save location logic ---------- */
  useEffect(() => {
    if (!isInitialized || Object.keys(locations).length === 0) return;
    
    const logicOut: Record<string, any> = {};
    Object.values(locations).forEach((loc) => {
      logicOut[loc.id] = loc.logic;
    });
    
    const jsonString = JSON.stringify(logicOut, null, 2);
    console.log("Saving location logic to localStorage, size:", jsonString.length);
    localStorage.setItem("celeste-location-logic", jsonString);
  }, [locations, isInitialized]);

  /* ---------- Save checked locations ---------- */
  useEffect(() => {
    if (!isInitialized || Object.keys(locations).length === 0) return;
    
    const checkedOut: Record<string, boolean> = {};
    Object.values(locations).forEach((loc) => {
      checkedOut[loc.id] = loc.checked;
    });
    
    localStorage.setItem("celeste-location-checked", JSON.stringify(checkedOut));
    console.log("Saved checked locations:", Object.values(locations).filter(l => l.checked).length);
  }, [locations, isInitialized]);

  /* ===============================
     AP Dynamic Mappings
  ================================ */
  const itemIdToMechanicRef = useRef<Record<number, keyof MechanicsState>>({});
  const locationNameToIdRef = useRef<Record<string, number>>({});


/* ===============================
   Archipelago - WebSocket
================================ */
const [reconnectAttempt, setReconnectAttempt] = useState(0);
const isConnectingRef = useRef(false);

useEffect(() => {
  // Prevent multiple connection attempts
  if (isConnectingRef.current) {
    console.log("Already connecting, skipping...");
    return;
  }

  // Don't recreate if we already have a working socket
  if (apSocket && apSocket.readyState === WebSocket.OPEN) {
    console.log("WebSocket already open, skipping creation");
    return;
  }

  isConnectingRef.current = true;
  
  // Clean up previous socket if it exists
  if (apSocket) {
    console.log("Cleaning up previous WebSocket");
    apSocket.close();
    apSocket = null;
  }

  console.log("Creating WebSocket connection...");
  apSocket = new WebSocket("ws://localhost:38281");

  apSocket.onmessage = (ev) => {
    try {
      const msgs = JSON.parse(ev.data);
      msgs.forEach(handleAPMessage);
    } catch (error) {
      console.error("Error parsing WebSocket message:", error);
      addLog(`Error parsing message: ${error}`);
    }
  };

  apSocket.onopen = () => {
    console.log("✅ WebSocket opened successfully");
    addLog("✅ WebSocket connected to Archipelago");
    isConnectingRef.current = false;
  };

  apSocket.onerror = (error) => {
    console.error("WebSocket error:", error);
    addLog("❌ WebSocket error - Check if Archipelago client is running on port 38281");
    isConnectingRef.current = false;
    
    // Close the socket on error
    if (apSocket) {
      apSocket.close();
      apSocket = null;
    }
  };

  apSocket.onclose = (e) => {
    console.log("WebSocket closed:", e.code, e.reason);
    addLog(`🔌 WebSocket closed (${e.code}) - Attempting to reconnect in 5 seconds...`);
    
    isConnectingRef.current = false;
    apSocket = null;
    
    // Auto-reconnect after 5 seconds using reconnectAttempt state
    setTimeout(() => {
      console.log("🔄 Attempting to reconnect...");
      addLog("🔄 Attempting to reconnect...");
      setReconnectAttempt(prev => prev + 1);
    }, 5000);
  };

  // Cleanup function - only runs on component unmount
  return () => {
    console.log("Component cleanup - closing WebSocket");
    if (apSocket) {
      apSocket.close(1000, "Component unmounting");
      apSocket = null;
    }
    isConnectingRef.current = false;
  };
}, [reconnectAttempt]); // Re-run when reconnectAttempt changes

  function handleAPMessage(msg: APMessage) {
    addLog(`AP → ${msg.cmd}`);

    if (msg.cmd === "RoomInfo") {
      apSocket?.send(
        JSON.stringify([
          {
            cmd: "Connect",
            game: "Celeste (Open World)",
            name: "BBB",
            password: "",
            tags: ["Tracker"],
            items_handling: 7, // Changed from 3 to 7 for full item handling
            uuid: getClientUUID(),
            version: { major: 0, minor: 5, build: 0, class: "Version" },
          },
        ])
      );
    }

    if (msg.cmd === "LocationChecks" || msg.cmd === "LocationInfo" || msg.cmd === "RoomUpdate") {
      // These might contain checked locations too
      console.log(`${msg.cmd} message:`, msg);
      
      // Try to extract checked locations
      let checkedLocations: number[] = [];
      
      if (msg.locations && Array.isArray(msg.locations)) {
        checkedLocations = msg.locations;
      } else if (msg.checked_locations && Array.isArray(msg.checked_locations)) {
        checkedLocations = msg.checked_locations;
      }
      
      if (checkedLocations.length > 0) {
        console.log(`${msg.cmd} has ${checkedLocations.length} checked locations`);
        
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
                console.log(`[${msg.cmd}] Marked as checked: ${loc.displayName}`);
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ ${msg.cmd} updated ${updatedCount} location(s)`);
          }
          return next;
        });
      }
    }

    if (msg.cmd === "ItemInfo") {
      // Handle initial items that were already received
      console.log("ItemInfo:", msg);
      
      if (msg.items && Array.isArray(msg.items)) {
        setMechanics((prev) => {
          const updated = { ...prev };
          let updatedCount = 0;
          
          for (const item of msg.items) {
            if (item.player === 1) { // Only our player's items
              const mech = itemIdToMechanicRef.current[item.item];
              if (mech && !updated[mech]) {
                updated[mech] = true;
                updatedCount++;
                addLog(`🔍 Loaded previously received item ${item.item} → ${mech}`);
              }
            }
          }
          
          if (updatedCount > 0) {
            addLog(`✅ Loaded ${updatedCount} previously received mechanics`);
          }
          return updated;
        });
      }
    }
    
    if (msg.cmd === "Connected") {
      addLog("✅ Successfully connected to Archipelago server");
      apSocket?.send(JSON.stringify([{ cmd: "GetDataPackage" }]));
      apSocket?.send(JSON.stringify([{ cmd: "Sync" }]));
      
      // Request initial items and checked locations
      setTimeout(() => {
        apSocket?.send(JSON.stringify([{ 
          cmd: "Get",
          keys: ["checked_locations", "received_items"]
        }]));
        addLog("🔄 Auto-syncing checked locations and items on connect");
      }, 1000);
    }
    
if (msg.cmd === "Retrieved") {
  console.log("=== RETRIEVED MESSAGE DEBUG ===");
  console.log("Full Retrieved message structure:", JSON.stringify(msg, null, 2));
  
  let checkedLocations: number[] = [];
  
  // Try multiple possible formats
  if (msg.data && typeof msg.data === 'object') {
    // Format 1: msg.data.checked_locations
    if (msg.data.checked_locations && Array.isArray(msg.data.checked_locations)) {
      checkedLocations = msg.data.checked_locations;
      console.log(`Format 1: Found checked_locations with ${checkedLocations.length} items`);
    }
    // Format 2: msg.data is the checked_locations array directly
    else if (Array.isArray(msg.data)) {
      checkedLocations = msg.data;
      console.log(`Format 2: Found checked_locations array with ${checkedLocations.length} items`);
    }
  } 
  else if (msg.keys && Array.isArray(msg.keys) && msg.values && Array.isArray(msg.values)) {
    // Format 3: Old format with keys and values arrays
    const checkedIndex = msg.keys.indexOf("checked_locations");
    if (checkedIndex !== -1) {
      const checkedValue = msg.values[checkedIndex];
      if (Array.isArray(checkedValue)) {
        checkedLocations = checkedValue;
        console.log(`Format 3: Found checked_locations with ${checkedLocations.length} items`);
      } else if (checkedValue && checkedValue.checked_locations && Array.isArray(checkedValue.checked_locations)) {
        checkedLocations = checkedValue.checked_locations;
        console.log(`Format 4: Found checked_locations in object with ${checkedLocations.length} items`);
      }
    }
  }
  
  if (checkedLocations.length > 0) {
    console.log("Checked locations found:", checkedLocations);
    
    setLocations((prev) => {
      const next = { ...prev };
      let updatedCount = 0;
      let alreadyCheckedCount = 0;
      
      Object.keys(next).forEach((key) => {
        const loc = next[key];
        if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
          if (!loc.checked) {
            next[key] = { ...loc, checked: true };
            updatedCount++;
            console.log(`Marked as checked: ${loc.displayName} (AP ID: ${loc.apLocationId})`);
          } else {
            alreadyCheckedCount++;
          }
        }
      });
      
      if (updatedCount > 0) {
        addLog(`✅ Loaded ${updatedCount} checked location(s) from server`);
        console.log(`Updated ${updatedCount} locations, ${alreadyCheckedCount} were already checked`);
      } else {
        addLog(`ℹ️ No new checked locations loaded (${alreadyCheckedCount} already checked)`);
      }
      return next;
    });
  } else {
    console.log("No checked locations found in Retrieved message");
    addLog("ℹ️ Retrieved message contained no checked locations data");
    
  }
  
  console.log("=== END RETRIEVED DEBUG ===");
}
    if (msg.cmd === "DataPackage") {
      const game = msg.data.games["Celeste (Open World)"];
      if (!game) {
        addLog("❌ No Celeste game found in DataPackage");
        return;
      }

      console.log("=== DATAPACKAGE DEBUG ===");
      console.log("Game found in DataPackage:", Object.keys(game));
      console.log("location_name_to_id count:", Object.keys(game.location_name_to_id || {}).length);
      console.log("item_name_to_id count:", Object.keys(game.item_name_to_id || {}).length);
      
      // Show first few location names
      const locationNames = Object.keys(game.location_name_to_id || {});
      console.log("First 10 location names:", locationNames.slice(0, 10));
      
      locationNameToIdRef.current = game.location_name_to_id;
      
      // Map AP item IDs to your mechanics (logic keys)
      if (game.item_name_to_id) {
        const itemIdToMechanic: Record<number, keyof MechanicsState> = {};
        
        Object.entries(game.item_name_to_id).forEach(([apItemName, apItemId]) => {
          const mechanicKey = getMechanicKeyFromAPName(apItemName);
          if (mechanicKey) {
            itemIdToMechanic[apItemId as number] = mechanicKey;
            addLog(`📋 Mapped AP item: ${apItemName} → ${mechanicKey}`);
          } else {
            // Log only important missing mappings
            if (!apItemName.includes("Trap") && !apItemName.includes("Key") && 
                !apItemName.includes("Gem") && !apItemName.includes("Strawberry") &&
                apItemName !== "Granny's House Keys") {
              addLog(`⚠️ No mapping found for AP item: ${apItemName}`);
            }
          }
        });
        
        itemIdToMechanicRef.current = itemIdToMechanic;
        
        // Process pending items
        if (pendingReceivedItems.length > 0) {
          console.log("Processing pending items:", pendingReceivedItems);
          setMechanics(prev => {
            const updated = { ...prev };
            let processedCount = 0;
            
            pendingReceivedItems.forEach(itemId => {
              const mech = itemIdToMechanic[itemId];
              if (mech && !updated[mech]) {
                updated[mech] = true;
                processedCount++;
                addLog(`🎁 Processed queued item ${itemId} → ${mech}`);
              }
            });
            
            pendingReceivedItems = [];
            if (processedCount > 0) {
              addLog(`✅ Processed ${processedCount} queued items`);
            }
            return updated;
          });
        }
      }

      // Map all locations, not just strawberries
      setLocations((prev) => {
        const next = { ...prev };
        let mappedCount = 0;
        let missingMatches: string[] = [];
        
        Object.entries(game.location_name_to_id).forEach(([apLocationName, apLocationId]) => {
          // Try to find matching location by name
          const locationKey = Object.keys(next).find(key => {
            const loc = next[key];
            
            // Try different matching strategies
            if (loc.apName && loc.apName === apLocationName) {
              return true;
            }
            
            // Try to match by display name (remove special chars)
            const cleanDisplayName = loc.displayName.toLowerCase().replace(/[^a-z0-9\s]/g, '');
            const cleanApName = apLocationName.toLowerCase().replace(/[^a-z0-9\s]/g, '');
            
            if (cleanDisplayName.includes(cleanApName) || cleanApName.includes(cleanDisplayName)) {
              return true;
            }
            
            // Try to match by ID
            if (loc.id.toLowerCase().includes(apLocationName.toLowerCase())) {
              return true;
            }
            
            return false;
          });
          
          if (locationKey) {
            if (!next[locationKey].apLocationId) {
              next[locationKey] = { ...next[locationKey], apLocationId: apLocationId as number };
              mappedCount++;
            }
          } else {
            missingMatches.push(apLocationName);
          }
        });
        
        addLog(`✅ Mapped ${mappedCount} locations to AP IDs`);
        
        // Log some missing matches for debugging
        if (missingMatches.length > 0) {
          console.log(`Could not map ${missingMatches.length} AP locations:`);
          console.log("Sample missing:", missingMatches.slice(0, 10));
        }
        
        return next;
      });

      addLog("✅ Loaded AP Data Package");
      
      // Now that we have the DataPackage, request checked locations again
      apSocket?.send(JSON.stringify([{ 
        cmd: "Get",
        keys: ["checked_locations"]
      }]));
    }
    
    if (msg.cmd === "ReceivedItems") {
      addLog(`📦 Received ${msg.items.length} items from Archipelago`);
      
      setMechanics((prev) => {
        console.log("Previous mechanics before ReceivedItems:", prev);
        const updated = { ...prev };
        let changesMade = false;
        
        for (const it of msg.items) {
          const mech = itemIdToMechanicRef.current[it.item];
          if (!mech) {
            pendingReceivedItems.push(it.item);
            addLog(`⏳ Queued item ${it.item} (mapping not ready)`);
            continue;
          }
          
          // Only update if not already true
          if (!updated[mech]) {
            updated[mech as keyof MechanicsState] = true;
            changesMade = true;
            addLog(`🎁 Received item ${it.item} → ${mech} = true`);
          } else {
            addLog(`ℹ️ Item ${it.item} → ${mech} already received`);
          }
        }
        
        // Force update if changes were made
        if (changesMade) {
          logMechanicsChange(prev, updated);
          return { ...updated }; // Return new object reference
        }
        return prev;
      });
    }

    if (msg.cmd === "RoomUpdate") {
      console.log("RoomUpdate:", msg);
      
      // Handle checked locations from RoomUpdate
      if (msg.checked_locations) {
        const checkedLocations = Array.isArray(msg.checked_locations) ? msg.checked_locations : [];
        console.log("RoomUpdate - checked locations:", checkedLocations);
        
        if (checkedLocations.length > 0) {
          setLocations((prev) => {
            const next = { ...prev };
            let updatedCount = 0;
            
            Object.keys(next).forEach((key) => {
              const loc = next[key];
              if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
                if (!loc.checked) {
                  // Create a new object instead of mutating
                  next[key] = { ...loc, checked: true };
                  updatedCount++;
                  addLog(`✅ Location checked: ${loc.displayName}`);
                }
              }
            });
            
            return next; // This returns a new object reference
          });
        }
      }
    }

    if (msg.cmd === "PrintJSON") {
      // Handle PrintJSON messages (chat messages)
      // Sometimes location checks come as PrintJSON messages
      if (msg.data && typeof msg.data === "string") {
        const dataStr = msg.data.toLowerCase();
        if (dataStr.includes("checked") || dataStr.includes("location")) {
          console.log("PrintJSON location check message:", msg.data);
          // Try to extract location information from the message
        }
      }
    }

    if (msg.cmd === "Bounced") {
      // Bounced messages often contain location checks
      console.log("Bounced message:", msg);
      
      if (msg.tags && msg.tags.includes("Client") && msg.data) {
        try {
          // Parse the bounced data which might contain location information
          const bouncedData = JSON.parse(msg.data);
          if (bouncedData.locations && Array.isArray(bouncedData.locations)) {
            const checkedLocations = bouncedData.locations;
            console.log("Bounced - checked locations:", checkedLocations);
            
            setLocations((prev) => {
              const next = { ...prev };
              let updatedCount = 0;
              
              Object.keys(next).forEach((key) => {
                const loc = next[key];
                if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
                  if (!loc.checked) {
                    next[key] = { ...loc, checked: true };
                    updatedCount++;
                    addLog(`✅ Bounced check: ${loc.displayName}`);
                  }
                }
              });
              
              return next;
            });
          }
        } catch (error) {
          console.error("Error parsing Bounced data:", error);
        }
      }
    }

    if (msg.cmd === "LocationInfo") {
      // LocationInfo messages contain location data
      console.log("LocationInfo:", msg);
      
      if (msg.locations && Array.isArray(msg.locations)) {
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          // LocationInfo can have an array of location objects
          msg.locations.forEach((locInfo: any) => {
            if (locInfo.status && locInfo.player && locInfo.location) {
              // Check if this location belongs to our player
              if (locInfo.player === 1) { // Player 1 is usually the local player
                Object.keys(next).forEach((key) => {
                  const loc = next[key];
                  if (loc.apLocationId === locInfo.location) {
                    const wasChecked = loc.checked;
                    const isChecked = locInfo.status > 0; // Status > 0 means checked
                    
                    if (!wasChecked && isChecked) {
                      next[key] = { ...loc, checked: true };
                      updatedCount++;
                      addLog(`✅ LocationInfo check: ${loc.displayName}`);
                    }
                  }
                });
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ Updated ${updatedCount} location(s) from LocationInfo`);
          }
          return next;
        });
      }
    }

    if (msg.cmd === "LocationChecks") {
      // When location checks are sent or received
      console.log("LocationChecks:", msg);
      if (msg.locations && Array.isArray(msg.locations)) {
        const checkedLocations = msg.locations;
        
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
                addLog(`✅ LocationChecks: ${loc.displayName}`);
              }
            }
          });
          
          return next;
        });
      }
    }
    
    if (msg.cmd === "SetReply") {
      // Handle SetReply messages which update client data
      if (msg.key === "checked_locations" && msg.value) {
        const checkedLocations = Array.isArray(msg.value) ? msg.value : [];
        console.log("SetReply - checked locations:", checkedLocations);
        
        setLocations((prev) => {
          const next = { ...prev };
          let updatedCount = 0;
          
          Object.keys(next).forEach((key) => {
            const loc = next[key];
            if (loc.apLocationId && checkedLocations.includes(loc.apLocationId)) {
              if (!loc.checked) {
                next[key] = { ...loc, checked: true };
                updatedCount++;
              }
            }
          });
          
          if (updatedCount > 0) {
            addLog(`✅ SetReply updated ${updatedCount} location(s)`);
          }
          return next;
        });
      }
    }

    if (msg.cmd === "ConnectionRefused") {
      addLog(`❌ Connection refused: ${msg.errors?.join(", ")}`);
    }

    if (msg.cmd === "ConnectionError") {
      addLog(`❌ Connection error: ${msg.errors?.join(", ")}`);
    }
  }

  /* ---------- Filter locations ---------- */
  const filteredLocations = Object.values(locations).filter((loc) => {
    // First, only show collectible locations
    if (!isCollectibleLocationState(loc)) return false;
    
    if (selectedChapter !== "all" && loc.chapter !== parseInt(selectedChapter)) return false;
    
    // Check side if filter is active
    if (selectedSide !== "all") {
      const locationSide = extractSideFromId(loc.id);
      if (!locationSide || locationSide !== selectedSide) return false;
    }
    
    // Check type if filter is active
    if (selectedType !== "all") {
      const locationType = extractTypeFromDisplayName(loc.displayName);
      if (!locationType || locationType !== selectedType) return false;
    }
    
    // Check reachability filter
    if (selectedReachability !== "all") {
      switch (selectedReachability) {
        case "reachable":
          if (!loc.reachable) return false;
          break;
        case "unreachable":
          if (loc.reachable) return false;
          break;
        case "checked":
          if (!loc.checked) return false;
          break;
        case "unchecked":
          if (loc.checked) return false;
          break;
      }
    }
    
    return true;
  });

  // Group filtered locations by chapter for display
  const locationsByChapter: Record<number, LocationState[]> = {};
  filteredLocations.forEach((loc) => {
    if (!locationsByChapter[loc.chapter]) {
      locationsByChapter[loc.chapter] = [];
    }
    locationsByChapter[loc.chapter].push(loc);
  });

  /* ---------- Handle location checking ---------- */
  const handleLocationCheck = (loc: LocationState) => {
    if (loc.apLocationId && loc.reachable && !loc.checked) {
      // Send check to Archipelago
      apSocket?.send(
        JSON.stringify([
          {
            cmd: "LocationChecks",
            locations: [loc.apLocationId],
          },
        ])
      );
      
      // Update local state immediately
      setLocations(prev => ({
        ...prev,
        [loc.id]: { ...prev[loc.id], checked: true }
      }));
      
      addLog(`📍 Sent check for ${loc.displayName}`);
    }
  };

  /* ===============================
     UI
  ================================ */

  if (!isInitialized) {
    return (
      <div style={{ padding: 20, maxWidth: 1200 }}>
        <h1>Celeste OW Archipelago Tracker</h1>
        <p>Loading locations and logic...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: 20, maxWidth: 1200 }}>
      <h1>🎮 Celeste OW Archipelago Tracker</h1>
      
      {/* Connection Status */}
      <div style={{ 
        padding: "10px", 
        marginBottom: "20px",
        background: apSocket?.readyState === WebSocket.OPEN ? "#4CAF50" : "#f44336",
        color: "white",
        borderRadius: "4px",
        fontWeight: "bold"
      }}>
        {apSocket?.readyState === WebSocket.OPEN ? "✅ Connected to Archipelago" : "❌ Not connected to Archipelago"}
      </div>

      {/* Main Controls */}
      <div style={{ 
        display: "flex", 
        gap: "20px", 
        marginBottom: "20px",
        flexWrap: "wrap",
        alignItems: "center"
      }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <input
            type="checkbox"
            checked={allowSeq}
            onChange={(e) => setAllowSeq(e.target.checked)}
          />
          <span>Allow Sequence Breaks</span>
        </label>
        <button
          onClick={() => {
            if (apSocket?.readyState === WebSocket.OPEN) {
              apSocket.send(JSON.stringify([{
                cmd: "Get",
                keys: ["checked_locations"]
              }]));
              addLog("📤 Manually sent Get request for checked_locations");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#FF9800",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Force Get Checked Locations
        </button>
        <button
          onClick={() => {
            console.log("=== CONNECTION TEST ===");
            console.log("WebSocket state:", apSocket?.readyState);
            console.log("Is connecting:", isConnectingRef.current);
            console.log("Reconnect attempt:", reconnectAttempt);
            
            if (apSocket?.readyState === WebSocket.OPEN) {
              // Test sending a Get request
              apSocket.send(JSON.stringify([{ 
                cmd: "Get",
                keys: ["checked_locations", "missing_locations", "received_items"]
              }]));
              addLog("🧪 Sent test Get request");
            } else {
              addLog("❌ WebSocket not open for testing");
              // Force a reconnection
              setReconnectAttempt(prev => prev + 1);
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#009688",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test Connection
        </button>

        <button
          onClick={() => {
            console.log("=== LOCATION MAPPING TEST ===");
            
            // Test if we have location_name_to_id
            if (Object.keys(locationNameToIdRef.current).length === 0) {
              console.log("❌ locationNameToIdRef is empty!");
              return;
            }
            
            // Test mapping for specific known locations
            const testMappings = [
              { apName: "Forsaken City - Crossing", expectedId: "Forsaken City A - Crossing" },
              { apName: "Old Site - Awake", expectedId: "Old Site A - Awake" },
              { apName: "Forsaken City - Chasm", expectedId: "Forsaken City A - Chasm" }
            ];
            
            testMappings.forEach(test => {
              const apId = locationNameToIdRef.current[test.apName];
              console.log(`AP Location "${test.apName}":`, apId ? `ID = ${apId}` : "NOT FOUND");
              
              // Find if this matches any of our locations
              const matchedLoc = Object.values(locations).find(loc => 
                loc.apLocationId === apId
              );
              console.log(`  Matched to local:`, matchedLoc ? matchedLoc.displayName : "NO MATCH");
            });
            
            // Check reverse mapping - our locations to AP IDs
            console.log("\nOur locations with AP IDs:");
            const locationsWithApIds = Object.values(locations).filter(loc => loc.apLocationId);
            locationsWithApIds.slice(0, 5).forEach(loc => {
              console.log(`  "${loc.displayName}" -> AP ID: ${loc.apLocationId}`);
              
              // Find the AP name for this ID
              const apName = Object.entries(locationNameToIdRef.current).find(
                ([_, id]) => id === loc.apLocationId
              );
              console.log(`    AP Name: ${apName ? apName[0] : "NOT FOUND"}`);
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#8BC34A",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test Location Mapping
        </button>
        <button
          onClick={() => {
            console.log("=== LOCATION MAPPING DEBUG ===");
            const locationsWithApIds = Object.values(locations).filter(loc => loc.apLocationId);
            const locationsWithoutApIds = Object.values(locations).filter(loc => !loc.apLocationId);
            
            console.log(`Total locations: ${Object.keys(locations).length}`);
            console.log(`Locations with AP IDs: ${locationsWithApIds.length}`);
            console.log(`Locations without AP IDs: ${locationsWithoutApIds.length}`);
            
            // Show sample of locations without AP IDs
            console.log("Sample locations without AP IDs:", 
              locationsWithoutApIds.slice(0, 10).map(l => l.displayName));
            
            // Show sample of AP location names from DataPackage
            console.log("Sample AP location names from DataPackage:", 
              Object.keys(locationNameToIdRef.current).slice(0, 10));
            
            // Check if specific known locations have AP IDs
            const testLocations = [
              "Old Site A - Crystal Heart?",
              "Forsaken City A - Strawberry 1",
              "Celestial Resort A - Strawberry 1"
            ];
            
            testLocations.forEach(testName => {
              const loc = Object.values(locations).find(l => l.displayName.includes(testName));
              if (loc) {
                console.log(`${testName}: AP ID = ${loc.apLocationId || 'NOT MAPPED'}`);
              }
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#607D8B",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Debug Location Mapping
        </button>
        <button
          onClick={() => {
            // Manually mark first 5 locations as checked for testing
            setLocations(prev => {
              const next = { ...prev };
              let count = 0;
              
              Object.keys(next).forEach(key => {
                if (count < 5 && !next[key].checked && next[key].apLocationId) {
                  next[key] = { ...next[key], checked: true };
                  count++;
                  console.log(`Marked ${next[key].displayName} as checked (AP ID: ${next[key].apLocationId})`);
                }
              });
              
              addLog(`✅ Manually checked ${count} locations for testing`);
              return next;
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#E91E63",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Check 5 Locations
        </button>
        <button
          onClick={() => {
            if (apSocket?.readyState === WebSocket.OPEN) {
              apSocket.send(JSON.stringify([{ 
                cmd: "Get",
                keys: ["checked_locations", "received_items", "missing_locations"]
              }]));
              addLog("🔄 Manually requested full state sync");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#795548",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Full State Sync
        </button>
        <button
          onClick={() => {
            setMechanics(prev => {
              const updated = { ...prev };
              // Toggle the first mechanic as a test
              const firstKey = Object.keys(updated)[0] as keyof MechanicsState;
              updated[firstKey] = !updated[firstKey];
              console.log(`Toggled ${firstKey}: ${!prev[firstKey]} -> ${updated[firstKey]}`);
              return updated;
            });
          }}
          style={{
            padding: "8px 16px",
            background: "#FF4081",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Toggle First Mechanic
        </button>
        <button
          onClick={() => {
            // Force a re-render of mechanics
            setMechanics(prev => ({ ...prev }));
            addLog("🔄 Manually refreshed mechanics display");
            
          }}
          style={{
            padding: "8px 16px",
            background: "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Refresh Mechanics Display
        </button>
        <button
          onClick={() => {
            // Manually request checked locations
            if (apSocket?.readyState === WebSocket.OPEN) {
              apSocket.send(JSON.stringify([{ 
                cmd: "Get",
                keys: ["checked_locations"]
              }]));
              addLog("🔄 Manually requested checked locations");
            }
          }}
          style={{
            padding: "8px 16px",
            background: "#9c27b0",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Sync Checked Locations
        </button>

        <button
          onClick={() => {
            // Test: Mark all reachable locations as checked
            setLocations(prev => {
              const next = { ...prev };
              Object.values(next).forEach(loc => {
                if (loc.reachable && !loc.checked) {
                  loc.checked = true;
                }
              });
              return next;
            });
            addLog("⚠️ Marked all reachable locations as checked (TEST)");
            
            // Force save
            const checkedOut: Record<string, boolean> = {};
            Object.values(locations).forEach((loc) => {
              checkedOut[loc.id] = loc.checked;
            });
            localStorage.setItem("celeste-location-checked", JSON.stringify(checkedOut));
          }}
          style={{
            padding: "8px 16px",
            background: "#ff9800",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Mark All Reachable
        </button>
        
        <button
          onClick={() => {
            setMechanics(prev => ({
              ...prev,
              "dashrefills": true
            }));
            console.log("Manually set dashrefills to true");
          }}
          style={{
            padding: "8px 16px",
            background: "#4CAF50",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Test: Set Dash Refills
        </button>
        
        <button
          onClick={() => {
            setLocations(prev => {
              const next = { ...prev };
              Object.keys(next).forEach(key => {
                next[key] = { ...next[key], checked: false };
              });
              return next;
            });
            addLog("🗑️ Cleared all checked locations");
            
            // Force save
            const checkedOut: Record<string, boolean> = {};
            Object.values(locations).forEach((loc) => {
              checkedOut[loc.id] = false;
            });
            localStorage.setItem("celeste-location-checked", JSON.stringify(checkedOut));
          }}
          style={{
            padding: "8px 16px",
            background: "#ff5722",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Clear All Checked
        </button>
        
        <button
          onClick={() => {
            console.log("=== DEBUG STATE ===");
            console.log("Total locations:", Object.keys(locations).length);
            console.log("Collectible locations:", filteredLocations.length);
            console.log("Mechanics:", mechanics);
            
            // Show connection info
            console.log("WebSocket state:", apSocket?.readyState);
          }}
          style={{
            padding: "8px 16px",
            background: "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Debug State
        </button>
      </div>

      {/* Filters */}
      <div style={{ 
        display: "grid", 
        gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", 
        gap: "15px",
        marginBottom: "30px",
        padding: "15px",
        background: "#f5f5f5",
        borderRadius: "8px"
      }}>
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Chapter:
          </label>
          <select 
            value={selectedChapter}
            onChange={(e) => setSelectedChapter(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All Chapters</option>
            {chapters.map(ch => (
              <option key={ch} value={ch}>
                {getAreaName(ch)} ({ch})
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Side:
          </label>
          <select 
            value={selectedSide}
            onChange={(e) => setSelectedSide(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All Sides</option>
            {sides.map(side => (
              <option key={side} value={side}>Side {side}</option>
            ))}
          </select>
        </div>
        
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Type:
          </label>
          <select 
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All Types</option>
            {types.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        
        {/* Add Reachability Filter */}
        <div>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Filter by Reachability:
          </label>
          <select 
            value={selectedReachability}
            onChange={(e) => setSelectedReachability(e.target.value)}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="all">All</option>
            <option value="reachable">Reachable Only</option>
            <option value="unreachable">Unreachable Only</option>
            <option value="checked">Checked Only</option>
            <option value="unchecked">Unchecked Only</option>
          </select>
        </div>
        
        <div style={{ display: "flex", alignItems: "flex-end" }}>
          <button
            onClick={() => {
              setSelectedChapter("all");
              setSelectedSide("all");
              setSelectedType("all");
              setSelectedReachability("all");
            }}
            style={{
              padding: "8px 16px",
              background: "#9e9e9e",
              color: "white",
              border: "none",
              borderRadius: "4px",
              width: "100%"
            }}
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ 
        display: "grid", 
        gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", 
        gap: "10px",
        marginBottom: "20px"
      }}>
        <div style={{ 
          padding: "10px", 
          background: "#e3f2fd", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Collectibles</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#e8f5e9", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Reachable</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => l.reachable).length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#fff3e0", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Checked</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => l.checked).length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#fce4ec", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Locked</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => !l.reachable).length}
          </div>
        </div>
        <div style={{ 
          padding: "10px", 
          background: "#f3e5f5", 
          borderRadius: "4px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "0.9em", color: "#666" }}>Unchecked</div>
          <div style={{ fontSize: "1.5em", fontWeight: "bold" }}>
            {filteredLocations.filter(l => !l.checked).length}
          </div>
        </div>
      </div>

      {/* Current Mechanics - Display with proper names */}
      <div style={{ marginBottom: "30px" }}>
        <h2>Current Mechanics ({Object.values(mechanics).filter(v => v).length}/{Object.keys(mechanics).length})</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 8 }}>
          {Object.entries(mechanics).map(([key, value]) => {
            const displayName = getMechanicDisplayName(key);
            
            return (
              <div key={key} style={{ 
                padding: 8, 
                background: value ? "#4CAF50" : "#f5f5f5",
                color: value ? "white" : "#333",
                border: `1px solid ${value ? "#4CAF50" : "#ddd"}`,
                borderRadius: "4px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }}>
                <span>{displayName}</span>
                <span style={{ fontWeight: "bold" }}>{value ? "✓" : "✗"}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Locations Display - Only Collectibles */}
      {Object.keys(locationsByChapter).length > 0 ? (
        Object.keys(locationsByChapter).sort((a, b) => parseInt(a) - parseInt(b)).map((chapterKey) => {
          const chapterNum = parseInt(chapterKey);
          const chapterLocations = locationsByChapter[chapterNum];
          
          return (
            <div key={chapterNum} style={{ marginBottom: "30px" }}>
              <h2 style={{ 
                padding: "10px", 
                background: "#673ab7", 
                color: "white",
                borderRadius: "4px"
              }}>
                {getAreaName(chapterNum)} (Chapter {chapterNum}) - {chapterLocations.length} collectibles
              </h2>
              
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(400px, 1fr))", gap: "15px" }}>
                {chapterLocations.map((loc) => {
                  const requiredKeys = getRequiredKeysFromLogic(loc.logic);
                  const locationSide = extractSideFromId(loc.id);
                  const locationType = extractTypeFromDisplayName(loc.displayName);
                  
                  return (
                    <div key={loc.id} style={{ 
                      opacity: loc.reachable ? 1 : 0.6,
                      padding: "15px",
                      background: loc.reachable ? (loc.checked ? "#000000ff" : "#000000ff") : "#000000ff",
                      border: `2px solid ${loc.checked ? "#2196F3" : loc.reachable ? "#4CAF50" : "#9e9e9e"}`,
                      borderRadius: "8px",
                      transition: "all 0.2s"
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "10px" }}>
                        <input
                          type="checkbox"
                          checked={loc.checked}
                          disabled={!loc.reachable || loc.checked}
                          onChange={() => handleLocationCheck(loc)}
                          style={{ 
                            transform: "scale(1.3)",
                            cursor: loc.reachable && !loc.checked ? "pointer" : "not-allowed"
                          }}
                        />
                        <span style={{ 
                          fontSize: "1.3em",
                          fontWeight: "bold" 
                        }}>
                          {loc.checked ? "🔵" : loc.reachable ? "🟢" : "⚫"}
                        </span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: "bold", fontSize: "1.1em" }}>{loc.displayName}</div>
                          <div style={{ fontSize: "0.9em", color: "#666", display: "flex", gap: "10px", marginTop: "4px" }}>
                            {locationSide && <span>Side: {locationSide}</span>}
                            {locationType && <span>Type: {locationType}</span>}
                          </div>
                        </div>
                        {loc.apLocationId && (
                          <span style={{ 
                            fontSize: "0.8em", 
                            color: "#666",
                            background: "#f0f0f0",
                            padding: "2px 6px",
                            borderRadius: "3px"
                          }}>
                            AP: {loc.apLocationId}
                          </span>
                        )}
                      </div>
                      
                      <div style={{ margin: "10px 0" }}>
                        <LogicEditor
                          logic={loc.logic}
                          onChange={(logic) =>
                            setLocations((prev) => ({
                              ...prev,
                              [loc.id]: { ...loc, logic },
                            }))
                          }
                          mechanics={mechanics}
                        />
                      </div>
                      
                      {/* Location Info */}
                      <div style={{ 
                        fontSize: "0.85em", 
                        color: "#666",
                        padding: "8px",
                        background: "#f9f9f9",
                        borderRadius: "4px",
                        border: "1px solid #eee"
                      }}>
                        <div style={{ marginBottom: "4px" }}>
                          <strong>Status:</strong> {loc.checked ? "Checked" : loc.reachable ? "Reachable" : "Locked"}
                        </div>
                        {requiredKeys.length > 0 && (
                          <div style={{ marginBottom: "4px" }}>
                            <strong>Required:</strong> {requiredKeys.map(k => getMechanicDisplayName(k)).join(", ")}
                          </div>
                        )}
                        <div style={{ 
                          color: loc.reachable ? "#4CAF50" : "#f44336",
                          fontWeight: "bold"
                        }}>
                          {loc.reachable ? "✓ Accessible" : "✗ Locked"}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })
      ) : (
        <div style={{ 
          padding: "20px", 
          textAlign: "center", 
          background: "#f5f5f5",
          borderRadius: "8px",
          marginBottom: "20px"
        }}>
          <h3>No collectible locations match the current filters</h3>
          <p>Try adjusting your filter settings</p>
        </div>
      )}

      {/* Debug Panel */}
      <details style={{ marginBottom: "20px" }}>
        <summary style={{ cursor: "pointer", padding: "10px", background: "#333", color: "white", borderRadius: "4px" }}>
          Debug Panel
        </summary>
        <div>
          <h3>Debug Logic Output</h3>
          <textarea 
            value={debugInfo}
            readOnly
            style={{
              width: "100%",
              height: "200px",
              fontFamily: "monospace",
              fontSize: "10px",
              marginBottom: "10px"
            }}
          />
          <button
            onClick={() => {
              // Test: Check if we can find locations for received items
              console.log("=== ITEM MATCHING TEST ===");
              const testItemIds = [211886104, 211886080, 211886085];
              
              testItemIds.forEach(itemId => {
                const locationKey = Object.keys(locations).find(key => 
                  locations[key].apItemId === itemId
                );
                
                if (locationKey) {
                  console.log(`✅ Item ${itemId} matches location: "${locations[locationKey].displayName}"`);
                } else {
                  console.log(`❌ Item ${itemId} - NO MATCHING LOCATION FOUND`);
                  
                  // Show all locations with apItemId
                  const locationsWithApItemId = Object.values(locations).filter(l => l.apItemId);
                  console.log(`Locations with apItemId:`, locationsWithApItemId.map(l => ({
                    displayName: l.displayName,
                    apItemId: l.apItemId
                  })));
                }
              });
            }}
            style={{
              padding: "8px 16px",
              background: "#ff5722",
              color: "white",
              border: "none",
              borderRadius: "4px"
            }}
          >
            Test Item Matching
          </button>
          <button
            onClick={() => {
              // Clear all mechanics for testing
              setMechanics(createEmptyRandomizedMechanics());
            }}
            style={{
              padding: "8px 16px",
              background: "#ff9800",
              color: "white",
              border: "none",
              borderRadius: "4px",
              marginRight: "10px"
            }}
          >
            Reset All Mechanics
          </button>
          
          <button
            onClick={() => {
              // Set all mechanics for testing
              setMechanics(prev => {
                const allTrue: MechanicsState = {} as MechanicsState;
                Object.keys(prev).forEach(key => {
                  allTrue[key as keyof MechanicsState] = true;
                });
                return allTrue;
              });
            }}
            style={{
              padding: "8px 16px",
              background: "#4CAF50",
              color: "white",
              border: "none",
              borderRadius: "4px"
            }}
          >
            Unlock All Mechanics
          </button>
        </div>
      </details>

      {/* Logs */}
      <div>
        <h2>Logs ({logs.length})</h2>
        <div
          style={{
            background: "#111",
            color: "#0f0",
            padding: 12,
            height: 300,
            overflowY: "auto",
            fontFamily: "monospace",
            fontSize: 12,
            borderRadius: "4px"
          }}
        >
          {logs.length > 0 ? (
            logs.map((l, i) => (
              <div key={i} style={{ 
                padding: "2px 0",
                borderBottom: i < logs.length - 1 ? "1px solid #333" : "none"
              }}>
                {l}
              </div>
            ))
          ) : (
            <div style={{ color: "#888", textAlign: "center", padding: "20px" }}>
              No logs yet
            </div>
          )}
        </div>
        <button
          onClick={() => setLogs([])}
          style={{
            marginTop: "10px",
            padding: "8px 16px",
            background: "#666",
            color: "white",
            border: "none",
            borderRadius: "4px"
          }}
        >
          Clear Logs
        </button>
      </div>
      <LocationDiagnostic locations={locations} />
      <LocationDebugger locations={locations} />
      <DebugOverlay mechanics={mechanics} locations={locations} />
    </div>
  );
}