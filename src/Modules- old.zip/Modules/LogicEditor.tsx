// In LogicEditor.tsx
import type { LogicNode } from "../Data/types";
import { ALL_LOGIC_KEYS, MECHANIC_MAPPINGS } from "../Logic/mechanicsMapping";

type Props = {
  logic: LogicNode;
  onChange: (logic: LogicNode) => void;
  mechanics?: Record<string, boolean>;
};

export default function LogicEditor({ logic, onChange, mechanics = {} }: Props) {
  if (logic.type === "has" || logic.type === "seq") {
  // Check if the mechanic is enabled
  // We need to check using the logic key
  const hasMechanic = logic.key ? mechanics[logic.key] || false : false;
  
  // Get display name for the selected logic key
  let displayName = logic.key || "Select a mechanic...";
  for (const mapping of Object.values(MECHANIC_MAPPINGS)) {
    if (mapping.logicKey === logic.key) {
      displayName = mapping.display;
      break;
    }
  }
  
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, margin: "4px 0" }}>
      <select
        value={logic.key || ""}
        onChange={e => onChange({ ...logic, key: e.target.value })}
        style={{ 
          padding: "4px 8px",
          border: `2px solid ${hasMechanic ? "#4CAF50" : "#f44336"}`,
          background: hasMechanic ? "#e8f5e8" : "#f5e8e8",
          borderRadius: "4px",
          minWidth: "200px"
        }}
      >
        <option value="">Select a mechanic...</option>
        {Object.entries(MECHANIC_MAPPINGS).map(([apKey, mapping]) => (
          <option key={mapping.logicKey} value={mapping.logicKey}>
            {mapping.display}
          </option>
        ))}
      </select>
      <span style={{ 
        color: hasMechanic ? "#4CAF50" : "#f44336",
        fontSize: "1.2em",
        fontWeight: "bold",
        minWidth: "20px"
      }}>
        {hasMechanic ? "✓" : "✗"}
      </span>

        <button
          onClick={() => {
            if (logic.type === "has") {
              onChange({ type: "seq", key: logic.key });
            } else {
              onChange({ type: "has", key: logic.key });
            }
          }}
          style={{
            padding: "2px 8px",
            background: logic.type === "seq" ? "#ff9800" : "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px",
            fontSize: "0.8em",
            cursor: "pointer"
          }}
        >
          {logic.type === "seq" ? "Seq" : "Has"}
        </button>
        <button
          onClick={() => onChange({ type: "has", key: "" })} // Changed to empty string
          style={{
            padding: "2px 8px",
            background: "#666",
            color: "white",
            border: "none",
            borderRadius: "4px",
            fontSize: "0.8em",
            cursor: "pointer"
          }}
        >
          Remove
        </button>
      </div>
    );
  }

  return (
    <div style={{ 
      marginLeft: 16, 
      borderLeft: "2px solid #ccc", 
      paddingLeft: 12,
      marginTop: 8,
      marginBottom: 8
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <strong style={{ 
          background: logic.type === "and" ? "#2196F3" : "#4CAF50",
          color: "white",
          padding: "2px 8px",
          borderRadius: "4px"
        }}>
          {logic.type.toUpperCase()}
        </strong>
        <button
          onClick={() => {
            if (logic.type === "and") {
              onChange({ type: "or", nodes: logic.nodes });
            } else {
              onChange({ type: "and", nodes: logic.nodes });
            }
          }}
          style={{
            padding: "2px 8px",
            background: "#ff9800",
            color: "white",
            border: "none",
            borderRadius: "4px",
            fontSize: "0.8em",
            cursor: "pointer"
          }}
        >
          Switch to {logic.type === "and" ? "OR" : "AND"}
        </button>
        <button
          onClick={() => {
            if (logic.nodes.length === 1) {
              // If only one node, replace with that node
              onChange(logic.nodes[0]);
            } else {
              onChange({ type: "has", key: ALL_LOGIC_KEYS[0] || "dashrefills" }); // Fixed: use logic key
            }
          }}
          style={{
            padding: "2px 8px",
            background: "#666",
            color: "white",
            border: "none",
            borderRadius: "4px",
            fontSize: "0.8em",
            cursor: "pointer"
          }}
        >
          Remove Group
        </button>
      </div>
      
      {logic.nodes.map((n, i) => (
        <LogicEditor
          key={i}
          logic={n}
          onChange={newNode => {
            const nodes = [...logic.nodes];
            nodes[i] = newNode;
            onChange({ ...logic, nodes });
          }}
          mechanics={mechanics}
        />
      ))}
      
      <div style={{ marginTop: 8 }}>
        <button 
          onClick={() => {
            const newNode = { 
              type: "has" as const, 
              key: ALL_LOGIC_KEYS[0] || "dashrefills" // Fixed: use logic key from array
            };
            onChange({ ...logic, nodes: [...logic.nodes, newNode] });
          }}
          style={{ 
            padding: "6px 12px",
            background: "#4CAF50",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
            fontSize: "0.9em",
            fontWeight: "bold"
          }}
        >
          + Add Condition
        </button>
        
        <button 
          onClick={() => {
            const newNode = { 
              type: "and" as const, 
              nodes: [{ 
                type: "has" as const, 
                key: ALL_LOGIC_KEYS[0] || "dashrefills" // Fixed: use logic key from array
              }] 
            };
            onChange({ ...logic, nodes: [...logic.nodes, newNode] });
          }}
          style={{ 
            marginLeft: "8px",
            padding: "6px 12px",
            background: "#2196F3",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
            fontSize: "0.9em"
          }}
        >
          + Add Group
        </button>
      </div>
    </div>
  );
}